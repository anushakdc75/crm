from sqlalchemy import Column, Integer, String, Float, Boolean, Date, Time, Text, DateTime, ARRAY, ForeignKey, JSON
from sqlalchemy.dialects.postgresql import ARRAY as PG_ARRAY
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(200), nullable=False)
    email = Column(String(200), unique=True)
    role = Column(String(50), default="rep")
    territory = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)


class Hcp(Base):
    __tablename__ = "hcps"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    specialty = Column(String(100), nullable=False)
    organization = Column(String(200), nullable=False)
    city = Column(String(100), nullable=False)
    state = Column(String(100), nullable=False)
    tier = Column(String(10), default="B")
    email = Column(String(200))
    phone = Column(String(50))
    opportunity_score = Column(Float, default=50.0)
    priority = Column(String(20), default="Medium")
    total_interactions = Column(Integer, default=0)
    last_visit = Column(Date)
    next_followup = Column(Date)
    created_at = Column(DateTime, default=datetime.utcnow)

    interactions = relationship("Interaction", back_populates="hcp")


class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    category = Column(String(100))
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


class Interaction(Base):
    __tablename__ = "interactions"

    id = Column(Integer, primary_key=True, index=True)
    hcp_id = Column(Integer, ForeignKey("hcps.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    date = Column(Date, nullable=False)
    time = Column(Time)
    interaction_type = Column(String(50), nullable=False)
    duration_minutes = Column(Integer, default=30)
    location = Column(String(200))
    products_discussed = Column(PG_ARRAY(String), default=[])
    samples_shared = Column(Boolean, default=False)
    literature_shared = Column(Boolean, default=False)
    pricing_discussed = Column(Boolean, default=False)
    competitor_mentioned = Column(Boolean, default=False)
    competitor_name = Column(String(200))
    interest_level = Column(String(20), default="Medium")
    objections_raised = Column(Text)
    prescribing_potential = Column(String(20))
    sentiment_score = Column(Float)
    followup_needed = Column(Boolean, default=False)
    followup_date = Column(Date)
    followup_mode = Column(String(50))
    followup_owner = Column(String(100))
    notes = Column(Text)
    ai_summary = Column(Text)
    confidence_score = Column(Float)
    is_draft = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    hcp = relationship("Hcp", back_populates="interactions")
    user = relationship("User")
