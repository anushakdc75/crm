from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth, dashboard, hcps, interactions, chat, insights, products

app = FastAPI(
    title="AI-First CRM HCP Module API",
    description="Pharmaceutical CRM API with LangGraph AI Agent",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health check
@app.get("/api/healthz")
def health_check():
    return {"status": "ok"}

# Include all routers
app.include_router(auth.router)
app.include_router(dashboard.router)
app.include_router(hcps.router)
app.include_router(interactions.router)
app.include_router(chat.router)
app.include_router(insights.router)
app.include_router(products.router)


@app.get("/")
def root():
    return {"message": "AI-First CRM HCP Module API", "docs": "/docs"}
