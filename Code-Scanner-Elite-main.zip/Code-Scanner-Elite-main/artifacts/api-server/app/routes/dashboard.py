from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, text
from datetime import date, timedelta
from typing import List
from app.db import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/api", tags=["dashboard"])


@router.get("/dashboard", response_model=schemas.DashboardData)
def get_dashboard(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    today = date.today()
    week_start = today - timedelta(days=7)
    month_start = today.replace(day=1)

    total_hcps = db.query(func.count(models.Hcp.id)).scalar() or 0
    week_interactions = db.query(func.count(models.Interaction.id)).filter(
        models.Interaction.date >= week_start
    ).scalar() or 0
    pending_followups = db.query(func.count(models.Interaction.id)).filter(
        models.Interaction.followup_needed == True,
        models.Interaction.followup_date >= today
    ).scalar() or 0
    high_opportunity_hcps = db.query(func.count(models.Hcp.id)).filter(
        models.Hcp.opportunity_score >= 70
    ).scalar() or 0
    at_risk_accounts = db.query(func.count(models.Hcp.id)).filter(
        models.Hcp.last_visit <= today - timedelta(days=45)
    ).scalar() or 0
    monthly_calls = db.query(func.count(models.Interaction.id)).filter(
        models.Interaction.date >= month_start
    ).scalar() or 0

    kpis = schemas.DashboardKpis(
        total_hcps=total_hcps,
        week_interactions=week_interactions,
        pending_followups=pending_followups,
        high_opportunity_hcps=high_opportunity_hcps,
        at_risk_accounts=at_risk_accounts,
        monthly_calls=monthly_calls
    )

    # Weekly trend (last 7 days)
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    weekly_trend = []
    for i in range(7):
        day_date = today - timedelta(days=6 - i)
        count = db.query(func.count(models.Interaction.id)).filter(
            models.Interaction.date == day_date
        ).scalar() or 0
        weekly_trend.append(schemas.WeeklyTrendPoint(
            day=day_date.strftime("%a"),
            count=count
        ))

    # Product interest distribution
    product_interest = []
    products = db.query(models.Product).all()
    total_interactions = db.query(func.count(models.Interaction.id)).scalar() or 1
    for product in products:
        # Count interactions mentioning this product
        count = db.query(func.count(models.Interaction.id)).filter(
            models.Interaction.products_discussed.any(product.name)
        ).scalar() or 0
        if count > 0:
            product_interest.append(schemas.ProductInterest(
                product=product.name,
                count=count,
                percentage=round(count / total_interactions * 100, 1)
            ))

    # If no product data yet, add demo data
    if not product_interest:
        demo_products = [
            ("GlucoCare", 45, 35.2),
            ("CardioMax", 32, 25.0),
            ("NeuroPlus", 28, 21.9),
            ("OrthoFlex", 18, 14.1),
            ("ImmunoX", 5, 3.9),
        ]
        product_interest = [
            schemas.ProductInterest(product=p, count=c, percentage=pct)
            for p, c, pct in demo_products
        ]

    # Region engagement
    region_data = db.query(
        models.Hcp.city,
        func.count(models.Interaction.id).label("interaction_count"),
        func.count(models.Hcp.id.distinct()).label("hcp_count")
    ).outerjoin(models.Interaction, models.Hcp.id == models.Interaction.hcp_id).group_by(models.Hcp.city).all()

    region_engagement = [
        schemas.RegionEngagement(city=row.city, count=row.interaction_count or 0, hcp_count=row.hcp_count or 0)
        for row in region_data
    ]

    # Recent interactions
    recent = db.query(models.Interaction).join(models.Hcp).order_by(
        models.Interaction.created_at.desc()
    ).limit(5).all()
    recent_interactions = [_interaction_to_out(i, db) for i in recent]

    # Pending follow-ups
    upcoming = db.query(models.Interaction).join(models.Hcp).filter(
        models.Interaction.followup_needed == True,
        models.Interaction.followup_date >= today
    ).order_by(models.Interaction.followup_date).limit(5).all()
    pending_followups_list = [
        schemas.PendingFollowup(
            id=i.id,
            hcp_name=db.query(models.Hcp).filter(models.Hcp.id == i.hcp_id).first().name if i.hcp_id else "Unknown",
            followup_date=i.followup_date,
            followup_mode=i.followup_mode,
            interest_level=i.interest_level
        ) for i in upcoming
    ]

    # Top HCPs by opportunity score
    top = db.query(models.Hcp).order_by(models.Hcp.opportunity_score.desc()).limit(5).all()
    top_hcps = [
        schemas.TopHcp(
            id=h.id,
            name=h.name,
            specialty=h.specialty,
            tier=h.tier,
            opportunity_score=h.opportunity_score or 50.0
        ) for h in top
    ]

    return schemas.DashboardData(
        kpis=kpis,
        weekly_trend=weekly_trend,
        product_interest=product_interest,
        region_engagement=region_engagement,
        recent_interactions=recent_interactions,
        pending_followups=pending_followups_list,
        top_hcps=top_hcps
    )


def _interaction_to_out(interaction: models.Interaction, db: Session) -> schemas.InteractionOut:
    hcp = db.query(models.Hcp).filter(models.Hcp.id == interaction.hcp_id).first()
    user = db.query(models.User).filter(models.User.id == interaction.user_id).first() if interaction.user_id else None
    return schemas.InteractionOut(
        id=interaction.id,
        hcp_id=interaction.hcp_id,
        hcp_name=hcp.name if hcp else "Unknown",
        hcp_specialty=hcp.specialty if hcp else None,
        date=interaction.date,
        time=str(interaction.time) if interaction.time else None,
        interaction_type=interaction.interaction_type,
        duration_minutes=interaction.duration_minutes,
        location=interaction.location,
        products_discussed=interaction.products_discussed or [],
        samples_shared=interaction.samples_shared or False,
        literature_shared=interaction.literature_shared or False,
        pricing_discussed=interaction.pricing_discussed or False,
        competitor_mentioned=interaction.competitor_mentioned or False,
        competitor_name=interaction.competitor_name,
        interest_level=interaction.interest_level or "Medium",
        objections_raised=interaction.objections_raised,
        prescribing_potential=interaction.prescribing_potential,
        sentiment_score=interaction.sentiment_score,
        followup_needed=interaction.followup_needed or False,
        followup_date=interaction.followup_date,
        followup_mode=interaction.followup_mode,
        followup_owner=interaction.followup_owner,
        notes=interaction.notes,
        ai_summary=interaction.ai_summary,
        confidence_score=interaction.confidence_score,
        created_at=interaction.created_at,
        rep_name=user.full_name if user else None
    )
