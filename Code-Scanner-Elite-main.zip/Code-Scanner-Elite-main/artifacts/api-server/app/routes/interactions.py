from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional
from datetime import date, timedelta
from app.db import get_db
from app import models, schemas, auth
from app.services.llm_provider import improve_notes

router = APIRouter(prefix="/api", tags=["interactions"])


def interaction_to_out(interaction: models.Interaction, db: Session) -> schemas.InteractionOut:
    hcp = db.query(models.Hcp).filter(models.Hcp.id == interaction.hcp_id).first()
    user = db.query(models.User).filter(models.User.id == interaction.user_id).first() if interaction.user_id else None
    return schemas.InteractionOut(
        id=interaction.id,
        hcp_id=interaction.hcp_id,
        hcp_name=hcp.name if hcp else "Unknown",
        hcp_specialty=hcp.specialty if hcp else None,
        date=interaction.date,
        time=str(interaction.time) if interaction.time else None,
        interaction_type=interaction.interaction_type,
        duration_minutes=interaction.duration_minutes,
        location=interaction.location,
        products_discussed=interaction.products_discussed or [],
        samples_shared=interaction.samples_shared or False,
        literature_shared=interaction.literature_shared or False,
        pricing_discussed=interaction.pricing_discussed or False,
        competitor_mentioned=interaction.competitor_mentioned or False,
        competitor_name=interaction.competitor_name,
        interest_level=interaction.interest_level or "Medium",
        objections_raised=interaction.objections_raised,
        prescribing_potential=interaction.prescribing_potential,
        sentiment_score=interaction.sentiment_score,
        followup_needed=interaction.followup_needed or False,
        followup_date=interaction.followup_date,
        followup_mode=interaction.followup_mode,
        followup_owner=interaction.followup_owner,
        notes=interaction.notes,
        ai_summary=interaction.ai_summary,
        confidence_score=interaction.confidence_score,
        created_at=interaction.created_at,
        rep_name=user.full_name if user else None
    )


@router.get("/interactions", response_model=schemas.InteractionListResponse)
def list_interactions(
    hcp_id: Optional[int] = Query(None),
    search: Optional[str] = Query(None),
    interaction_type: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    query = db.query(models.Interaction).join(models.Hcp, models.Interaction.hcp_id == models.Hcp.id)
    if hcp_id:
        query = query.filter(models.Interaction.hcp_id == hcp_id)
    if search:
        query = query.filter(
            models.Hcp.name.ilike(f"%{search}%") |
            models.Interaction.notes.ilike(f"%{search}%") |
            models.Interaction.ai_summary.ilike(f"%{search}%")
        )
    if interaction_type:
        query = query.filter(models.Interaction.interaction_type == interaction_type)
    total = query.count()
    interactions = query.order_by(models.Interaction.date.desc()).offset((page - 1) * limit).limit(limit).all()

    return schemas.InteractionListResponse(
        data=[interaction_to_out(i, db) for i in interactions],
        total=total,
        page=page,
        limit=limit
    )


@router.post("/interactions", response_model=schemas.InteractionOut, status_code=201)
def create_interaction(
    request: schemas.InteractionCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    hcp = db.query(models.Hcp).filter(models.Hcp.id == request.hcp_id).first()
    if not hcp:
        raise HTTPException(status_code=404, detail="HCP not found")

    data = request.model_dump()

    # Auto-generate AI summary if notes provided
    if data.get("notes") and not data.get("ai_summary"):
        try:
            data["ai_summary"] = improve_notes(data["notes"])
        except Exception:
            data["ai_summary"] = data["notes"]

    # Set confidence score
    filled_fields = sum(1 for v in data.values() if v is not None and v != "" and v != [] and v is not False)
    data["confidence_score"] = min(0.95, filled_fields / 15)

    interaction = models.Interaction(**data, user_id=current_user.id)
    db.add(interaction)

    # Update HCP stats
    hcp.total_interactions = (hcp.total_interactions or 0) + 1
    hcp.last_visit = request.date
    if request.followup_date:
        hcp.next_followup = request.followup_date

    # Update opportunity score based on interest level
    score_map = {"Hot": 90, "High": 75, "Medium": 55, "Low": 30}
    if request.interest_level in score_map:
        current = hcp.opportunity_score or 50
        new_score = score_map[request.interest_level]
        hcp.opportunity_score = round(current * 0.4 + new_score * 0.6, 1)

    # Update priority
    if hcp.opportunity_score >= 75:
        hcp.priority = "High"
    elif hcp.opportunity_score >= 50:
        hcp.priority = "Medium"
    else:
        hcp.priority = "Low"

    db.commit()
    db.refresh(interaction)
    return interaction_to_out(interaction, db)


@router.get("/interactions/{interaction_id}", response_model=schemas.InteractionOut)
def get_interaction(
    interaction_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    interaction = db.query(models.Interaction).filter(models.Interaction.id == interaction_id).first()
    if not interaction:
        raise HTTPException(status_code=404, detail="Interaction not found")
    return interaction_to_out(interaction, db)


@router.put("/interactions/{interaction_id}", response_model=schemas.InteractionOut)
def update_interaction(
    interaction_id: int,
    request: schemas.InteractionCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    interaction = db.query(models.Interaction).filter(models.Interaction.id == interaction_id).first()
    if not interaction:
        raise HTTPException(status_code=404, detail="Interaction not found")

    for key, value in request.model_dump().items():
        setattr(interaction, key, value)

    db.commit()
    db.refresh(interaction)
    return interaction_to_out(interaction, db)


@router.delete("/interactions/{interaction_id}", response_model=schemas.DeleteResponse)
def delete_interaction(
    interaction_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    interaction = db.query(models.Interaction).filter(models.Interaction.id == interaction_id).first()
    if not interaction:
        raise HTTPException(status_code=404, detail="Interaction not found")
    db.delete(interaction)
    db.commit()
    return schemas.DeleteResponse(success=True, message="Interaction deleted successfully")


@router.get("/history/{hcp_id}", response_model=schemas.HcpHistoryResponse)
def get_hcp_history(
    hcp_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    hcp = db.query(models.Hcp).filter(models.Hcp.id == hcp_id).first()
    if not hcp:
        raise HTTPException(status_code=404, detail="HCP not found")

    interactions = db.query(models.Interaction).filter(
        models.Interaction.hcp_id == hcp_id
    ).order_by(models.Interaction.date.desc()).limit(10).all()

    interaction_outs = [interaction_to_out(i, db) for i in interactions]

    # Product trends
    products_set = set()
    objections = []
    for i in interactions:
        if i.products_discussed:
            products_set.update(i.products_discussed)
        if i.objections_raised:
            objections.append(i.objections_raised)

    # Summary
    if interactions:
        last = interactions[0]
        summary = (
            f"Dr. {hcp.name} has {len(interactions)} recorded interactions. "
            f"Last contact: {last.date} ({last.interaction_type}). "
            f"Current interest level: {last.interest_level}. "
            f"Opportunity score: {hcp.opportunity_score}/100."
        )
    else:
        summary = f"No interaction history found for Dr. {hcp.name}. Consider scheduling an initial outreach."

    last_contacted = interactions[0].date if interactions else None

    return schemas.HcpHistoryResponse(
        hcp=schemas.HcpOut.model_validate(hcp),
        interactions=interaction_outs,
        summary=summary,
        product_trends=list(products_set),
        past_objections=objections[:5],
        last_contacted=last_contacted
    )
