from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, or_
from typing import Optional, List
from datetime import date, timedelta
from app.db import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/api/hcps", tags=["hcps"])


@router.get("", response_model=schemas.HcpListResponse)
def list_hcps(
    search: Optional[str] = Query(None),
    specialty: Optional[str] = Query(None),
    city: Optional[str] = Query(None),
    tier: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    query = db.query(models.Hcp)

    if search:
        search_filter = f"%{search}%"
        query = query.filter(
            or_(
                models.Hcp.name.ilike(search_filter),
                models.Hcp.organization.ilike(search_filter),
                models.Hcp.city.ilike(search_filter)
            )
        )
    if specialty:
        query = query.filter(models.Hcp.specialty.ilike(f"%{specialty}%"))
    if city:
        query = query.filter(models.Hcp.city.ilike(f"%{city}%"))
    if tier:
        query = query.filter(models.Hcp.tier == tier)

    total = query.count()
    hcps = query.order_by(models.Hcp.opportunity_score.desc()).offset((page - 1) * limit).limit(limit).all()

    return schemas.HcpListResponse(
        data=[schemas.HcpOut.model_validate(h) for h in hcps],
        total=total,
        page=page,
        limit=limit
    )


@router.post("", response_model=schemas.HcpOut, status_code=201)
def create_hcp(
    request: schemas.HcpCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    hcp = models.Hcp(**request.model_dump())
    db.add(hcp)
    db.commit()
    db.refresh(hcp)
    return schemas.HcpOut.model_validate(hcp)


@router.get("/{hcp_id}", response_model=schemas.HcpDetail)
def get_hcp(
    hcp_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    hcp = db.query(models.Hcp).filter(models.Hcp.id == hcp_id).first()
    if not hcp:
        raise HTTPException(status_code=404, detail="HCP not found")

    interactions = db.query(models.Interaction).filter(
        models.Interaction.hcp_id == hcp_id
    ).order_by(models.Interaction.date.desc()).limit(10).all()

    interaction_outs = [_interaction_to_out(i, db) for i in interactions]

    # Aggregate products discussed
    products_set = set()
    for interaction in interactions:
        if interaction.products_discussed:
            products_set.update(interaction.products_discussed)

    # AI summary based on interaction history
    if interactions:
        last = interactions[0]
        ai_summary = (
            f"Dr. {hcp.name} ({hcp.specialty}) at {hcp.organization} in {hcp.city} has been engaged "
            f"{len(interactions)} times. Last interaction was a {last.interaction_type} on {last.date} "
            f"with interest level '{last.interest_level}'. Products discussed include "
            f"{', '.join(list(products_set)[:3]) if products_set else 'none'}."
        )
    else:
        ai_summary = f"Dr. {hcp.name} ({hcp.specialty}) at {hcp.organization} has not been contacted yet. Consider scheduling an initial visit."

    # Suggested next actions based on opportunity score
    suggested_actions = []
    if hcp.opportunity_score >= 80:
        suggested_actions = [
            "Schedule priority visit this week",
            "Bring MSL support for clinical deep-dive",
            "Prepare customized pricing proposal"
        ]
    elif hcp.opportunity_score >= 60:
        suggested_actions = [
            "Send clinical paper on key product",
            "Schedule follow-up within 2 weeks",
            "Share product sample pack"
        ]
    else:
        suggested_actions = [
            "Re-engage with updated product portfolio",
            "Send educational material",
            "Schedule introductory call"
        ]

    # Sentiment trend
    if interactions:
        interest_levels = [i.interest_level for i in interactions if i.interest_level]
        hot_high = sum(1 for l in interest_levels if l in ["Hot", "High"])
        trend = "Positive" if hot_high > len(interest_levels) / 2 else "Neutral" if interest_levels else "Unknown"
    else:
        trend = "Not yet engaged"

    return schemas.HcpDetail(
        hcp=schemas.HcpOut.model_validate(hcp),
        recent_interactions=interaction_outs,
        products_discussed=list(products_set),
        ai_summary=ai_summary,
        suggested_actions=suggested_actions,
        sentiment_trend=trend
    )


@router.put("/{hcp_id}", response_model=schemas.HcpOut)
def update_hcp(
    hcp_id: int,
    request: schemas.HcpCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    hcp = db.query(models.Hcp).filter(models.Hcp.id == hcp_id).first()
    if not hcp:
        raise HTTPException(status_code=404, detail="HCP not found")

    for key, value in request.model_dump().items():
        setattr(hcp, key, value)

    db.commit()
    db.refresh(hcp)
    return schemas.HcpOut.model_validate(hcp)


def _interaction_to_out(interaction: models.Interaction, db: Session) -> schemas.InteractionOut:
    hcp = db.query(models.Hcp).filter(models.Hcp.id == interaction.hcp_id).first()
    user = db.query(models.User).filter(models.User.id == interaction.user_id).first() if interaction.user_id else None
    return schemas.InteractionOut(
        id=interaction.id,
        hcp_id=interaction.hcp_id,
        hcp_name=hcp.name if hcp else "Unknown",
        hcp_specialty=hcp.specialty if hcp else None,
        date=interaction.date,
        time=str(interaction.time) if interaction.time else None,
        interaction_type=interaction.interaction_type,
        duration_minutes=interaction.duration_minutes,
        location=interaction.location,
        products_discussed=interaction.products_discussed or [],
        samples_shared=interaction.samples_shared or False,
        literature_shared=interaction.literature_shared or False,
        pricing_discussed=interaction.pricing_discussed or False,
        competitor_mentioned=interaction.competitor_mentioned or False,
        competitor_name=interaction.competitor_name,
        interest_level=interaction.interest_level or "Medium",
        objections_raised=interaction.objections_raised,
        prescribing_potential=interaction.prescribing_potential,
        sentiment_score=interaction.sentiment_score,
        followup_needed=interaction.followup_needed or False,
        followup_date=interaction.followup_date,
        followup_mode=interaction.followup_mode,
        followup_owner=interaction.followup_owner,
        notes=interaction.notes,
        ai_summary=interaction.ai_summary,
        confidence_score=interaction.confidence_score,
        created_at=interaction.created_at,
        rep_name=user.full_name if user else None
    )
