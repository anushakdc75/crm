from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=schemas.LoginResponse)
def login(request: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == request.username).first()

    # For demo: also check plain password "admin123" / "demo123" for quick demos
    demo_passwords = {"admin": "admin123", "rep1": "rep123", "rep2": "rep123", "demo": "demo123"}
    plain_match = demo_passwords.get(request.username) == request.password

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password"
        )

    # Check password - try bcrypt first, then plain demo password
    valid = False
    try:
        valid = auth.verify_password(request.password, user.password_hash)
    except Exception:
        pass

    if not valid:
        valid = plain_match

    if not valid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password"
        )

    access_token = auth.create_access_token(data={"sub": user.username})

    return schemas.LoginResponse(
        access_token=access_token,
        token_type="bearer",
        user=schemas.UserOut.model_validate(user)
    )


@router.get("/me", response_model=schemas.UserOut)
def get_me(current_user: models.User = Depends(auth.get_current_user)):
    return schemas.UserOut.model_validate(current_user)
