import uuid
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app import models, schemas, auth
from app.services.llm_provider import extract_interaction_from_chat
from app.graph.agent import run_agent

router = APIRouter(prefix="/api", tags=["chat"])

# In-memory conversation store (in production, use Redis)
conversation_store: dict = {}


@router.post("/chat", response_model=schemas.ChatResponse)
def send_chat(
    request: schemas.ChatRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    conversation_id = request.conversation_id or str(uuid.uuid4())

    # Get conversation history
    history = conversation_store.get(conversation_id, [])

    # Extract interaction data using LLM
    result = extract_interaction_from_chat(request.message, history)

    # Update conversation history
    history.append({"role": "user", "content": request.message})
    history.append({"role": "assistant", "content": result.get("reply", "")})
    conversation_store[conversation_id] = history[-20:]  # Keep last 20 messages

    # Parse extracted data
    extracted = result.get("extracted_data", {})
    if not extracted and "hcp_name" in result:
        # The result itself might be the extracted data
        extracted = result

    extracted_data = schemas.ExtractedInteractionData(
        hcp_name=extracted.get("hcp_name"),
        specialty=extracted.get("specialty"),
        organization=extracted.get("organization"),
        date=str(extracted.get("date")) if extracted.get("date") else None,
        time=extracted.get("time"),
        interaction_type=extracted.get("interaction_type"),
        products_discussed=extracted.get("products_discussed", []),
        competitor_mentioned=extracted.get("competitor_mentioned"),
        competitor_name=extracted.get("competitor_name"),
        interest_level=extracted.get("interest_level"),
        sentiment_score=extracted.get("sentiment_score"),
        followup_needed=extracted.get("followup_needed"),
        followup_date=str(extracted.get("followup_date")) if extracted.get("followup_date") else None,
        notes=extracted.get("notes"),
        ai_summary=extracted.get("ai_summary")
    )

    follow_up_questions = result.get("follow_up_questions", [])
    if not follow_up_questions:
        # Generate default questions based on missing fields
        if not extracted.get("interest_level"):
            follow_up_questions.append("What was the doctor's interest level? (Low/Medium/High/Hot)")
        if not extracted.get("followup_needed"):
            follow_up_questions.append("Is a follow-up needed, and if so when?")
        if not extracted.get("products_discussed"):
            follow_up_questions.append("Which products were discussed in this meeting?")

    suggested_actions = result.get("suggested_actions", [
        "Fill in the structured form with extracted data",
        "Review and confirm the AI-extracted details",
        "Submit the interaction log"
    ])

    reply = result.get("reply", "I've processed your message. Please review the extracted information.")

    return schemas.ChatResponse(
        reply=reply,
        conversation_id=conversation_id,
        extracted_data=extracted_data,
        follow_up_questions=follow_up_questions[:3],
        suggested_actions=suggested_actions[:3],
        confidence_score=result.get("confidence_score", 0.75)
    )


@router.post("/agent/run", response_model=schemas.AgentResponse)
def run_agent_endpoint(
    request: schemas.AgentRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    result = run_agent(
        user_input=request.input,
        session_id=request.session_id
    )

    extracted = result.get("extracted_data", {})
    extracted_data = schemas.ExtractedInteractionData(
        hcp_name=extracted.get("hcp_name"),
        specialty=extracted.get("specialty"),
        organization=extracted.get("organization"),
        date=str(extracted.get("date")) if extracted.get("date") else None,
        time=extracted.get("time"),
        interaction_type=extracted.get("interaction_type"),
        products_discussed=extracted.get("products_discussed", []),
        competitor_mentioned=extracted.get("competitor_mentioned"),
        competitor_name=extracted.get("competitor_name"),
        interest_level=extracted.get("interest_level"),
        sentiment_score=extracted.get("sentiment_score"),
        followup_needed=extracted.get("followup_needed"),
        followup_date=str(extracted.get("followup_date")) if extracted.get("followup_date") else None,
        notes=extracted.get("notes"),
        ai_summary=extracted.get("ai_summary")
    )

    next_best_actions = [
        schemas.NextBestAction(
            action=a.get("action", ""),
            reason=a.get("reason", ""),
            priority=a.get("priority", "medium")
        )
        for a in result.get("next_best_actions", [])
    ]

    return schemas.AgentResponse(
        output=result["output"],
        tool_used=result.get("tool_used"),
        nodes_executed=result["nodes_executed"],
        extracted_data=extracted_data,
        next_best_actions=next_best_actions,
        confidence_score=result["confidence_score"],
        session_id=result["session_id"]
    )
