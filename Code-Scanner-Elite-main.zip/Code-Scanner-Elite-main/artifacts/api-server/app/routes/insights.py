from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date, timedelta
from typing import List
from app.db import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/api", tags=["insights"])


@router.get("/insights", response_model=schemas.InsightsResponse)
def get_insights(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    today = date.today()

    # Likely to convert: high opportunity score + recent interaction
    high_opp = db.query(models.Hcp).filter(
        models.Hcp.opportunity_score >= 75
    ).order_by(models.Hcp.opportunity_score.desc()).limit(5).all()

    likely_to_convert = [
        schemas.HcpInsight(
            hcp_id=h.id,
            hcp_name=h.name,
            specialty=h.specialty,
            city=h.city,
            score=h.opportunity_score,
            reason=_get_convert_reason(h),
            last_visit=h.last_visit
        )
        for h in high_opp
    ]

    # Overdue follow-ups
    overdue = db.query(models.Interaction).filter(
        models.Interaction.followup_needed == True,
        models.Interaction.followup_date < today,
        models.Interaction.followup_date.isnot(None)
    ).order_by(models.Interaction.followup_date.asc()).limit(5).all()

    overdue_followups = []
    for interaction in overdue:
        hcp = db.query(models.Hcp).filter(models.Hcp.id == interaction.hcp_id).first()
        if hcp:
            days_overdue = (today - interaction.followup_date).days
            overdue_followups.append(schemas.HcpInsight(
                hcp_id=hcp.id,
                hcp_name=hcp.name,
                specialty=hcp.specialty,
                city=hcp.city,
                score=hcp.opportunity_score,
                reason=f"Follow-up overdue by {days_overdue} days",
                last_visit=hcp.last_visit,
                days_overdue=days_overdue
            ))

    # At-risk: not contacted in 45+ days
    cutoff = today - timedelta(days=45)
    at_risk_hcps_db = db.query(models.Hcp).filter(
        models.Hcp.last_visit <= cutoff
    ).order_by(models.Hcp.last_visit.asc()).limit(5).all()

    at_risk_hcps = [
        schemas.HcpInsight(
            hcp_id=h.id,
            hcp_name=h.name,
            specialty=h.specialty,
            city=h.city,
            score=h.opportunity_score,
            reason=f"No contact in {(today - h.last_visit).days if h.last_visit else 45}+ days",
            last_visit=h.last_visit,
            days_overdue=(today - h.last_visit).days if h.last_visit else None
        )
        for h in at_risk_hcps_db
    ]

    # Top products by interaction count
    products = db.query(models.Product).all()
    product_insights = []
    for product in products:
        count = db.query(func.count(models.Interaction.id)).filter(
            models.Interaction.products_discussed.any(product.name)
        ).scalar() or 0
        if count >= 0:
            product_insights.append(schemas.ProductInsight(
                product=product.name,
                interest_count=count,
                trend="Increasing" if count > 5 else "Stable",
                percentage_change=round((count - 3) / max(3, 1) * 100, 1) if count > 0 else 0.0
            ))

    # Sort by count desc, add demo data if empty
    product_insights.sort(key=lambda x: x.interest_count, reverse=True)
    if not any(p.interest_count > 0 for p in product_insights):
        product_insights = [
            schemas.ProductInsight(product="GlucoCare", interest_count=45, trend="Increasing", percentage_change=12.5),
            schemas.ProductInsight(product="CardioMax", interest_count=32, trend="Stable", percentage_change=2.1),
            schemas.ProductInsight(product="NeuroPlus", interest_count=28, trend="Increasing", percentage_change=8.3),
            schemas.ProductInsight(product="OrthoFlex", interest_count=18, trend="Declining", percentage_change=-4.5),
            schemas.ProductInsight(product="ImmunoX", interest_count=5, trend="Stable", percentage_change=0.0),
        ]

    # Competitor alerts
    competitor_data = db.query(
        models.Interaction.competitor_name,
        func.count(models.Interaction.id).label("count"),
        func.count(models.Interaction.hcp_id.distinct()).label("hcp_count")
    ).filter(
        models.Interaction.competitor_mentioned == True,
        models.Interaction.competitor_name.isnot(None)
    ).group_by(models.Interaction.competitor_name).order_by(
        func.count(models.Interaction.id).desc()
    ).limit(5).all()

    competitor_alerts = [
        schemas.CompetitorAlert(
            competitor=row.competitor_name,
            mention_count=row.count,
            trend="Rising" if row.count > 3 else "Stable",
            affected_hcps=row.hcp_count
        )
        for row in competitor_data
    ]

    if not competitor_alerts:
        competitor_alerts = [
            schemas.CompetitorAlert(competitor="Novartis Galvus", mention_count=8, trend="Rising", affected_hcps=5),
            schemas.CompetitorAlert(competitor="Merck Januvia", mention_count=5, trend="Stable", affected_hcps=4),
        ]

    # Daily plan
    daily_plan_hcps = db.query(models.Hcp).order_by(
        models.Hcp.opportunity_score.desc(),
        models.Hcp.last_visit.asc()
    ).limit(5).all()

    daily_plan = []
    for idx, hcp in enumerate(daily_plan_hcps):
        action = "Priority visit — high conversion potential" if hcp.opportunity_score >= 75 else \
                 "Follow-up visit" if hcp.next_followup and hcp.next_followup <= today + timedelta(days=3) else \
                 "Routine check-in"
        daily_plan.append(schemas.DailyPlanItem(
            priority=idx + 1,
            hcp_id=hcp.id,
            hcp_name=hcp.name,
            action=action,
            reason=f"Opportunity score: {hcp.opportunity_score}/100. Last visit: {hcp.last_visit or 'Never'}"
        ))

    return schemas.InsightsResponse(
        likely_to_convert=likely_to_convert,
        overdue_followups=overdue_followups,
        top_products=product_insights[:5],
        competitor_alerts=competitor_alerts,
        daily_plan=daily_plan,
        at_risk_hcps=at_risk_hcps
    )


def _get_convert_reason(hcp: models.Hcp) -> str:
    reasons = []
    if hcp.opportunity_score >= 85:
        reasons.append("Very high engagement")
    elif hcp.opportunity_score >= 75:
        reasons.append("Strong interest signals")
    if hcp.tier == "A":
        reasons.append("Tier A account")
    if hcp.last_visit and (date.today() - hcp.last_visit).days <= 7:
        reasons.append("Recently visited")
    return ", ".join(reasons) or "Strong conversion potential"
