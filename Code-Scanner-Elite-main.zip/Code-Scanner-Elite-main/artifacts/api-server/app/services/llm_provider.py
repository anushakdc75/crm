import json
import re
from typing import Optional
from app.config import OPENAI_API_KEY, GROQ_API_KEY, get_llm_provider


def get_llm_client():
    provider = get_llm_provider()
    if provider == "openai":
        from openai import OpenAI
        return OpenAI(api_key=OPENAI_API_KEY), "openai"
    elif provider == "groq":
        from groq import Groq
        return Groq(api_key=GROQ_API_KEY), "groq"
    return None, "mock"


def chat_completion(messages: list, temperature: float = 0.3, max_tokens: int = 2000) -> str:
    client, provider = get_llm_client()

    if provider == "mock":
        return _mock_response(messages)

    if provider == "openai":
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens
        )
        return response.choices[0].message.content

    elif provider == "groq":
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens
        )
        return response.choices[0].message.content

    return _mock_response(messages)


def _mock_response(messages: list) -> str:
    last_user_msg = ""
    for m in reversed(messages):
        if m.get("role") == "user":
            last_user_msg = m.get("content", "")
            break

    return json.dumps({
        "reply": f"I understood your message about: '{last_user_msg[:50]}...'. I've extracted some key details from your notes. Please review and confirm.",
        "extracted_data": {
            "hcp_name": "Dr. Sample Doctor",
            "products_discussed": ["GlucoCare"],
            "interest_level": "Medium",
            "followup_needed": True,
            "ai_summary": "Mock AI summary - Add OpenAI or Groq API key for real AI responses."
        },
        "follow_up_questions": ["What was the interest level?", "When is the follow-up?"],
        "confidence_score": 0.6
    })


EXTRACTION_SYSTEM_PROMPT = """You are an AI assistant for a pharmaceutical CRM system. 
Your job is to extract structured information from sales rep notes about doctor visits.

Extract the following information from the user's message:
- hcp_name: Doctor's name
- specialty: Doctor's medical specialty  
- organization: Hospital/clinic name
- date: Visit date (ISO format YYYY-MM-DD if mentioned)
- time: Visit time (if mentioned)
- interaction_type: Type (Visit/Call/Webinar/Email/Conference/Lunch Meet)
- products_discussed: List of pharmaceutical products mentioned
- competitor_mentioned: Boolean if competitor mentioned
- competitor_name: Competitor name if mentioned
- interest_level: Low/Medium/High/Hot based on tone
- sentiment_score: 1-10 based on how positive the interaction was
- followup_needed: Boolean
- followup_date: Follow-up date if mentioned (ISO format)
- notes: Clean professional summary of the interaction
- ai_summary: A professional 2-3 sentence summary

Known products: GlucoCare, CardioMax, NeuroPlus, OrthoFlex, ImmunoX

Return a JSON object with these fields. Use null for fields not mentioned.
Also return:
- reply: A helpful conversational response acknowledging what was captured
- follow_up_questions: List of 2-3 questions to fill in missing critical info
- suggested_actions: List of 2-3 next best actions
- confidence_score: 0.0-1.0 confidence in extraction accuracy"""


def extract_interaction_from_chat(message: str, conversation_history: list = []) -> dict:
    messages = [
        {"role": "system", "content": EXTRACTION_SYSTEM_PROMPT},
        *conversation_history,
        {"role": "user", "content": message}
    ]

    response_text = chat_completion(messages)

    # Try to parse as JSON
    try:
        # Extract JSON from response (might be wrapped in markdown)
        json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
        if json_match:
            data = json.loads(json_match.group())
            return data
    except (json.JSONDecodeError, AttributeError):
        pass

    # Fallback structure
    return {
        "reply": response_text,
        "extracted_data": {
            "ai_summary": response_text,
            "products_discussed": []
        },
        "follow_up_questions": ["What was the doctor's interest level?"],
        "suggested_actions": ["Schedule follow-up"],
        "confidence_score": 0.5
    }


AI_IMPROVE_PROMPT = """You are a professional pharmaceutical CRM note writer.
Improve the following field sales rep notes into a professional, concise CRM entry.
Keep it factual, professional, and structured. 3-5 sentences max.

Notes to improve:
{notes}

Return only the improved notes text, no other commentary."""


def improve_notes(notes: str) -> str:
    messages = [
        {"role": "user", "content": AI_IMPROVE_PROMPT.format(notes=notes)}
    ]
    return chat_completion(messages, temperature=0.2)
