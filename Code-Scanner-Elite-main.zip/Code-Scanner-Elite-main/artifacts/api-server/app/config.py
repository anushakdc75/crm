import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "")
SECRET_KEY = os.getenv("SESSION_SECRET", "pharma-crm-secret-key-2024")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

# LLM provider selection
def get_llm_provider() -> str:
    if OPENAI_API_KEY:
        return "openai"
    elif GROQ_API_KEY:
        return "groq"
    return "mock"
