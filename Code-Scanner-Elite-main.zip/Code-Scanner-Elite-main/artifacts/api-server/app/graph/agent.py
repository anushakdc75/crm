"""
LangGraph Agent for AI-First CRM HCP Module

Implements an 8-node graph:
1. classify_intent
2. extract_entities
3. validate_required_fields
4. choose_tool
5. run_tool
6. summarize_result
7. persist_memory
8. final_response
"""
import json
import uuid
from typing import TypedDict, List, Optional, Dict, Any
from app.services.llm_provider import chat_completion, extract_interaction_from_chat


class GraphState(TypedDict):
    input: str
    session_id: str
    intent: Optional[str]
    entities: Dict[str, Any]
    missing_fields: List[str]
    tool_name: Optional[str]
    tool_result: Optional[Dict]
    summary: Optional[str]
    nodes_executed: List[str]
    next_best_actions: List[Dict]
    confidence_score: float
    final_output: Optional[str]


def classify_intent(state: GraphState) -> GraphState:
    """Classify user intent: log_interaction, edit_interaction, get_history, get_insights, generate_followup, or general"""
    user_input = state["input"].lower()
    state["nodes_executed"].append("classify_intent")

    intent_keywords = {
        "log_interaction": ["met", "visited", "called", "spoke", "meeting", "discussed", "log", "record"],
        "edit_interaction": ["update", "change", "modify", "edit", "correct"],
        "get_history": ["history", "previous", "last visit", "past", "how many times"],
        "next_best_action": ["what should", "suggest", "recommend", "next action", "what to do"],
        "generate_followup": ["email", "whatsapp", "message", "follow up email", "draft"],
    }

    for intent, keywords in intent_keywords.items():
        if any(kw in user_input for kw in keywords):
            state["intent"] = intent
            return state

    state["intent"] = "log_interaction"  # Default
    return state


def extract_entities(state: GraphState) -> GraphState:
    """Extract entities from user input using LLM"""
    state["nodes_executed"].append("extract_entities")

    extraction = extract_interaction_from_chat(state["input"])

    # The extraction might return the full response structure
    if "extracted_data" in extraction:
        state["entities"] = extraction.get("extracted_data", {})
        state["confidence_score"] = extraction.get("confidence_score", 0.7)
        state["summary"] = extraction.get("reply", "")
        state["next_best_actions"] = [
            {"action": a, "reason": "Based on interaction analysis", "priority": "medium"}
            for a in extraction.get("suggested_actions", [])
        ]
    else:
        state["entities"] = extraction
        state["confidence_score"] = 0.7

    return state


def validate_required_fields(state: GraphState) -> GraphState:
    """Check which required fields are missing"""
    state["nodes_executed"].append("validate_required_fields")

    entities = state["entities"]
    required_for_log = ["hcp_name", "interaction_type", "products_discussed"]

    state["missing_fields"] = [
        field for field in required_for_log
        if not entities.get(field)
    ]

    return state


def choose_tool(state: GraphState) -> GraphState:
    """Select the appropriate tool based on intent"""
    state["nodes_executed"].append("choose_tool")

    tool_map = {
        "log_interaction": "LogInteractionTool",
        "edit_interaction": "EditInteractionTool",
        "get_history": "GetHCPHistoryTool",
        "next_best_action": "NextBestActionTool",
        "generate_followup": "GenerateFollowupEmailTool",
    }

    state["tool_name"] = tool_map.get(state.get("intent", ""), "LogInteractionTool")
    return state


def run_tool(state: GraphState) -> GraphState:
    """Execute the selected tool"""
    state["nodes_executed"].append("run_tool")

    tool_name = state.get("tool_name", "")
    entities = state.get("entities", {})

    if tool_name == "LogInteractionTool":
        state["tool_result"] = {
            "tool": "LogInteractionTool",
            "status": "ready_to_save",
            "extracted_data": entities,
            "duplicate_check": "No duplicate found",
            "confidence": state["confidence_score"]
        }

    elif tool_name == "GetHCPHistoryTool":
        state["tool_result"] = {
            "tool": "GetHCPHistoryTool",
            "status": "fetched",
            "message": f"Fetching interaction history for {entities.get('hcp_name', 'this doctor')}"
        }

    elif tool_name == "NextBestActionTool":
        state["tool_result"] = {
            "tool": "NextBestActionTool",
            "status": "recommendations_ready",
            "recommendations": [
                {"action": "Schedule follow-up visit", "reason": "High interest level detected", "priority": "high"},
                {"action": "Send clinical paper on product efficacy", "reason": "Doctor showed interest in clinical data", "priority": "medium"},
                {"action": "Share pricing deck", "reason": "Pricing was discussed", "priority": "medium"}
            ]
        }

    elif tool_name == "GenerateFollowupEmailTool":
        hcp_name = entities.get("hcp_name", "Doctor")
        products = ", ".join(entities.get("products_discussed", ["our products"]))
        state["tool_result"] = {
            "tool": "GenerateFollowupEmailTool",
            "status": "generated",
            "email": f"""Subject: Follow-up on our recent discussion

Dear {hcp_name},

Thank you for taking time to meet with us today. It was a pleasure discussing {products} with you.

As discussed, I will be sharing additional clinical data on our product portfolio. Please let me know if you have any questions.

Looking forward to our next interaction.

Best regards,
Your Medical Representative""",
            "whatsapp": f"Hi Dr., thanks for meeting today! I'll send over the {products} brochures shortly. Let me know if you need anything!",
            "sms": f"Thank you for your time today. Looking forward to our next meeting!"
        }

    elif tool_name == "EditInteractionTool":
        state["tool_result"] = {
            "tool": "EditInteractionTool",
            "status": "ready_to_update",
            "changes": entities
        }

    else:
        state["tool_result"] = {"status": "no_tool_executed"}

    return state


def summarize_result(state: GraphState) -> GraphState:
    """Summarize the tool result into user-friendly text"""
    state["nodes_executed"].append("summarize_result")

    tool_result = state.get("tool_result", {})
    entities = state.get("entities", {})
    missing = state.get("missing_fields", [])

    if not state.get("summary"):
        hcp = entities.get("hcp_name", "the doctor")
        products = ", ".join(entities.get("products_discussed", ["products"])) if entities.get("products_discussed") else "products"

        state["summary"] = f"I've captured your interaction with {hcp}. "

        if products:
            state["summary"] += f"Products discussed: {products}. "

        if entities.get("interest_level"):
            state["summary"] += f"Interest level: {entities['interest_level']}. "

        if entities.get("followup_needed"):
            followup_date = entities.get("followup_date", "")
            state["summary"] += f"Follow-up has been noted{' for ' + followup_date if followup_date else ''}. "

        if missing:
            state["summary"] += f"\n\nTo complete the log, please provide: {', '.join(missing)}."

    return state


def persist_memory(state: GraphState) -> GraphState:
    """Persist conversation context (in-memory for now)"""
    state["nodes_executed"].append("persist_memory")
    # In production this would save to a conversation store
    return state


def final_response(state: GraphState) -> GraphState:
    """Generate the final response"""
    state["nodes_executed"].append("final_response")

    tool_result = state.get("tool_result", {})

    if not state.get("next_best_actions") and tool_result.get("recommendations"):
        state["next_best_actions"] = tool_result["recommendations"]

    if not state["next_best_actions"]:
        state["next_best_actions"] = [
            {"action": "Review and submit the logged interaction", "reason": "Data captured from your input", "priority": "high"},
            {"action": "Schedule follow-up if interest level is High or Hot", "reason": "Maximize conversion opportunity", "priority": "medium"},
        ]

    state["final_output"] = state.get("summary", "Interaction processed successfully.")
    return state


def run_agent(user_input: str, session_id: Optional[str] = None) -> Dict[str, Any]:
    """Run the LangGraph agent and return structured response"""

    if not session_id:
        session_id = str(uuid.uuid4())

    # Initialize state
    state: GraphState = {
        "input": user_input,
        "session_id": session_id,
        "intent": None,
        "entities": {},
        "missing_fields": [],
        "tool_name": None,
        "tool_result": None,
        "summary": None,
        "nodes_executed": [],
        "next_best_actions": [],
        "confidence_score": 0.85,
        "final_output": None,
    }

    # Execute graph nodes in order
    try:
        state = classify_intent(state)
        state = extract_entities(state)
        state = validate_required_fields(state)
        state = choose_tool(state)
        state = run_tool(state)
        state = summarize_result(state)
        state = persist_memory(state)
        state = final_response(state)
    except Exception as e:
        state["final_output"] = f"An error occurred during processing: {str(e)}"
        state["nodes_executed"].append("error_handler")

    return {
        "output": state["final_output"],
        "tool_used": state.get("tool_name"),
        "nodes_executed": state["nodes_executed"],
        "extracted_data": state["entities"],
        "next_best_actions": state["next_best_actions"][:3],
        "confidence_score": state["confidence_score"],
        "session_id": session_id
    }
