from pydantic import BaseModel, EmailStr
from typing import Optional, List, Any
from datetime import date, time, datetime


class HealthStatus(BaseModel):
    status: str


class LoginRequest(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    id: int
    username: str
    full_name: str
    email: Optional[str] = None
    role: str
    territory: Optional[str] = None

    class Config:
        from_attributes = True


class LoginResponse(BaseModel):
    access_token: str
    token_type: str
    user: UserOut


class HcpBase(BaseModel):
    name: str
    specialty: str
    organization: str
    city: str
    state: str
    tier: str = "B"
    email: Optional[str] = None
    phone: Optional[str] = None


class HcpCreate(HcpBase):
    pass


class HcpOut(HcpBase):
    id: int
    opportunity_score: float = 50.0
    priority: str = "Medium"
    total_interactions: int = 0
    last_visit: Optional[date] = None
    next_followup: Optional[date] = None

    class Config:
        from_attributes = True


class HcpListResponse(BaseModel):
    data: List[HcpOut]
    total: int
    page: int
    limit: int


class HcpDetail(BaseModel):
    hcp: HcpOut
    recent_interactions: List[Any]
    products_discussed: List[str]
    ai_summary: str
    suggested_actions: List[str]
    sentiment_trend: str


class InteractionBase(BaseModel):
    hcp_id: int
    date: date
    time: Optional[str] = None
    interaction_type: str
    duration_minutes: Optional[int] = 30
    location: Optional[str] = None
    products_discussed: Optional[List[str]] = []
    samples_shared: Optional[bool] = False
    literature_shared: Optional[bool] = False
    pricing_discussed: Optional[bool] = False
    competitor_mentioned: Optional[bool] = False
    competitor_name: Optional[str] = None
    interest_level: str = "Medium"
    objections_raised: Optional[str] = None
    prescribing_potential: Optional[str] = None
    sentiment_score: Optional[float] = None
    followup_needed: Optional[bool] = False
    followup_date: Optional[date] = None
    followup_mode: Optional[str] = None
    followup_owner: Optional[str] = None
    notes: Optional[str] = None
    is_draft: Optional[bool] = False


class InteractionCreate(InteractionBase):
    pass


class InteractionOut(BaseModel):
    id: int
    hcp_id: int
    hcp_name: str
    hcp_specialty: Optional[str] = None
    date: date
    time: Optional[str] = None
    interaction_type: str
    duration_minutes: Optional[int] = None
    location: Optional[str] = None
    products_discussed: List[str] = []
    samples_shared: bool = False
    literature_shared: bool = False
    pricing_discussed: bool = False
    competitor_mentioned: bool = False
    competitor_name: Optional[str] = None
    interest_level: str
    objections_raised: Optional[str] = None
    prescribing_potential: Optional[str] = None
    sentiment_score: Optional[float] = None
    followup_needed: bool = False
    followup_date: Optional[date] = None
    followup_mode: Optional[str] = None
    followup_owner: Optional[str] = None
    notes: Optional[str] = None
    ai_summary: Optional[str] = None
    confidence_score: Optional[float] = None
    created_at: datetime
    rep_name: Optional[str] = None

    class Config:
        from_attributes = True


class InteractionListResponse(BaseModel):
    data: List[InteractionOut]
    total: int
    page: int
    limit: int


class ExtractedInteractionData(BaseModel):
    hcp_name: Optional[str] = None
    specialty: Optional[str] = None
    organization: Optional[str] = None
    date: Optional[str] = None
    time: Optional[str] = None
    interaction_type: Optional[str] = None
    products_discussed: List[str] = []
    competitor_mentioned: Optional[bool] = None
    competitor_name: Optional[str] = None
    interest_level: Optional[str] = None
    sentiment_score: Optional[float] = None
    followup_needed: Optional[bool] = None
    followup_date: Optional[str] = None
    notes: Optional[str] = None
    ai_summary: Optional[str] = None


class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    context: Optional[dict] = None


class ChatResponse(BaseModel):
    reply: str
    conversation_id: str
    extracted_data: ExtractedInteractionData
    follow_up_questions: List[str] = []
    suggested_actions: List[str] = []
    confidence_score: float = 0.8


class NextBestAction(BaseModel):
    action: str
    reason: str
    priority: str


class AgentRequest(BaseModel):
    input: str
    session_id: Optional[str] = None
    tool: Optional[str] = None
    context: Optional[dict] = None


class AgentResponse(BaseModel):
    output: str
    tool_used: Optional[str] = None
    nodes_executed: List[str] = []
    extracted_data: ExtractedInteractionData
    next_best_actions: List[NextBestAction] = []
    confidence_score: float = 0.85
    session_id: str


class HcpHistoryResponse(BaseModel):
    hcp: HcpOut
    interactions: List[InteractionOut]
    summary: str
    product_trends: List[str]
    past_objections: List[str]
    last_contacted: Optional[date] = None


class WeeklyTrendPoint(BaseModel):
    day: str
    count: int


class ProductInterest(BaseModel):
    product: str
    count: int
    percentage: float


class RegionEngagement(BaseModel):
    city: str
    count: int
    hcp_count: int


class DashboardKpis(BaseModel):
    total_hcps: int
    week_interactions: int
    pending_followups: int
    high_opportunity_hcps: int
    at_risk_accounts: int
    monthly_calls: int


class PendingFollowup(BaseModel):
    id: int
    hcp_name: str
    followup_date: Optional[date]
    followup_mode: Optional[str]
    interest_level: Optional[str]


class TopHcp(BaseModel):
    id: int
    name: str
    specialty: str
    tier: str
    opportunity_score: float


class DashboardData(BaseModel):
    kpis: DashboardKpis
    weekly_trend: List[WeeklyTrendPoint]
    product_interest: List[ProductInterest]
    region_engagement: List[RegionEngagement]
    recent_interactions: List[InteractionOut]
    pending_followups: List[PendingFollowup] = []
    top_hcps: List[TopHcp] = []


class HcpInsight(BaseModel):
    hcp_id: int
    hcp_name: str
    specialty: str
    city: str
    score: float
    reason: str
    last_visit: Optional[date] = None
    days_overdue: Optional[int] = None


class ProductInsight(BaseModel):
    product: str
    interest_count: int
    trend: str
    percentage_change: float


class CompetitorAlert(BaseModel):
    competitor: str
    mention_count: int
    trend: str
    affected_hcps: int


class DailyPlanItem(BaseModel):
    priority: int
    hcp_id: int
    hcp_name: str
    action: str
    reason: str


class InsightsResponse(BaseModel):
    likely_to_convert: List[HcpInsight]
    overdue_followups: List[HcpInsight]
    top_products: List[ProductInsight]
    competitor_alerts: List[CompetitorAlert]
    daily_plan: List[DailyPlanItem]
    at_risk_hcps: List[HcpInsight]


class ProductOut(BaseModel):
    id: int
    name: str
    category: Optional[str] = None
    description: Optional[str] = None

    class Config:
        from_attributes = True


class DeleteResponse(BaseModel):
    success: bool
    message: str
