#!/bin/bash
set -e
cd /home/runner/workspace/artifacts/api-server

echo "Starting FastAPI server on port ${PORT:-8080}..."
python3 -m uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8080} --reload
