import { useEffect, ReactNode } from "react";
import { useLocation, Link } from "wouter";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "@/store";
import { logout } from "@/features/authSlice";
import { useGetMe } from "@workspace/api-client-react";
import {
  LayoutDashboard,
  Users,
  MessageSquarePlus,
  History,
  Lightbulb,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  User as UserIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toggleSidebar } from "@/features/uiSlice";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { setCredentials } from "@/features/authSlice";

interface NavItemProps {
  href: string;
  icon: React.ElementType;
  label: string;
  collapsed: boolean;
}

function NavItem({ href, icon: Icon, label, collapsed }: NavItemProps) {
  const [location] = useLocation();
  const isActive = location === href || (href !== "/" && location.startsWith(href));

  return (
    <Link href={href}>
      <div
        className={cn(
          "flex items-center gap-3 px-3 py-2 rounded-md transition-colors cursor-pointer group",
          isActive
            ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
            : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
        )}
        title={collapsed ? label : undefined}
      >
        <Icon className={cn("w-5 h-5 shrink-0", isActive ? "text-primary" : "text-sidebar-foreground/70 group-hover:text-sidebar-foreground")} />
        {!collapsed && <span className="truncate">{label}</span>}
      </div>
    </Link>
  );
}

export function AppLayout({ children }: { children: ReactNode }) {
  const [, setLocation] = useLocation();
  const dispatch = useDispatch();
  const { isAuthenticated, token, user } = useSelector((state: RootState) => state.auth);
  const { sidebar_collapsed } = useSelector((state: RootState) => state.ui);

  const { data: me, isError, isLoading } = useGetMe({
    query: {
      enabled: isAuthenticated && !!token,
      retry: false,
    } as any,
    request: {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  useEffect(() => {
    if (isError) {
      dispatch(logout());
      setLocation("/login");
    }
  }, [isError, dispatch, setLocation]);

  useEffect(() => {
    if (me && token && !user) {
      dispatch(setCredentials({ user: me, token }));
    }
  }, [me, token, user, dispatch]);

  if (!isAuthenticated) {
    return null; // Will redirect
  }

  const handleLogout = () => {
    dispatch(logout());
    setLocation("/login");
  };

  return (
    <div className="min-h-screen bg-background flex w-full">
      {/* Sidebar */}
      <aside
        className={cn(
          "bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 z-10 sticky top-0 h-screen",
          sidebar_collapsed ? "w-16" : "w-64"
        )}
      >
        <div className="h-14 flex items-center justify-between px-3 border-b border-sidebar-border">
          {!sidebar_collapsed && (
            <div className="font-semibold text-lg tracking-tight text-sidebar-foreground flex items-center gap-2 truncate">
              <div className="w-6 h-6 rounded bg-primary flex items-center justify-center text-primary-foreground text-xs">
                A
              </div>
              Copilot CRM
            </div>
          )}
          {sidebar_collapsed && (
            <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground text-sm font-bold mx-auto">
              A
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            className={cn("h-8 w-8 text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent", sidebar_collapsed && "hidden")}
            onClick={() => dispatch(toggleSidebar())}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>

        {sidebar_collapsed && (
          <div className="mt-2 flex justify-center">
             <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
                onClick={() => dispatch(toggleSidebar())}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
          </div>
        )}

        <div className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
          <NavItem href="/dashboard" icon={LayoutDashboard} label="Dashboard" collapsed={sidebar_collapsed} />
          <NavItem href="/hcps" icon={Users} label="HCP Directory" collapsed={sidebar_collapsed} />
          <NavItem href="/log-interaction" icon={MessageSquarePlus} label="Log Interaction" collapsed={sidebar_collapsed} />
          <NavItem href="/interactions" icon={History} label="History" collapsed={sidebar_collapsed} />
          <NavItem href="/insights" icon={Lightbulb} label="AI Insights" collapsed={sidebar_collapsed} />
        </div>

        <div className="p-2 border-t border-sidebar-border space-y-1">
          <NavItem href="/settings" icon={Settings} label="Settings" collapsed={sidebar_collapsed} />
          <div
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-md transition-colors cursor-pointer text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground group"
            )}
            onClick={handleLogout}
            title={sidebar_collapsed ? "Logout" : undefined}
          >
            <LogOut className="w-5 h-5 shrink-0 group-hover:text-sidebar-foreground" />
            {!sidebar_collapsed && <span className="truncate">Logout</span>}
          </div>
        </div>

        {!sidebar_collapsed && (
          <div className="p-4 border-t border-sidebar-border flex items-center gap-3">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-primary/10 text-primary">
                {user?.full_name?.charAt(0) || <UserIcon className="h-4 w-4" />}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-medium text-sidebar-foreground truncate">
                {isLoading ? "Loading..." : user?.full_name || "User"}
              </span>
              <span className="text-xs text-sidebar-foreground/60 truncate">
                {user?.role || "Medical Rep"}
              </span>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-background overflow-hidden h-screen">
        <div className="flex-1 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
}