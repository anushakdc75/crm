import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import "./lib/api-init";

import LoginPage from "@/pages/login";
import DashboardPage from "@/pages/dashboard";
import HcpListPage from "@/pages/hcps";
import HcpDetailPage from "@/pages/hcp-detail";
import HcpNewPage from "@/pages/hcp-new";
import LogInteractionPage from "@/pages/log-interaction";
import InteractionsPage from "@/pages/interactions";
import InsightsPage from "@/pages/insights";
import SettingsPage from "@/pages/settings";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30_000 },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={LoginPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/dashboard" component={DashboardPage} />
      <Route path="/hcps" component={HcpListPage} />
      <Route path="/hcps/new" component={HcpNewPage} />
      <Route path="/hcps/:id" component={HcpDetailPage} />
      <Route path="/log-interaction" component={LogInteractionPage} />
      <Route path="/interactions" component={InteractionsPage} />
      <Route path="/insights" component={InsightsPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
