import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Lightbulb, TrendingUp, AlertCircle, Target, Loader2, RefreshCw } from "lucide-react";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface InsightCard {
  type: string;
  title: string;
  description: string;
  priority: "high" | "medium" | "low";
  action?: string;
}

const priorityColors = {
  high: "border-l-red-500 bg-red-50",
  medium: "border-l-yellow-500 bg-yellow-50",
  low: "border-l-blue-500 bg-blue-50",
};

const priorityBadge = {
  high: "destructive",
  medium: "secondary",
  low: "outline",
} as const;

export default function InsightsPage() {
  const { token } = useSelector((state: RootState) => state.auth);
  const [territory, setTerritory] = useState("all");
  const [period, setPeriod] = useState("30");
  const [insights, setInsights] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const fetchInsights = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/insights?territory=${territory}&period_days=${period}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      setInsights(data);
    } catch {
      setInsights(null);
    } finally {
      setLoading(false);
    }
  };

  const insightsList: InsightCard[] = insights?.insights || [];
  const summary = insights?.summary || {};

  return (
    <AppLayout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Lightbulb className="w-6 h-6 text-yellow-500" /> AI Insights
            </h1>
            <p className="text-sm text-muted-foreground mt-1">AI-powered analysis of your territory and HCP engagement</p>
          </div>
        </div>

        {/* Controls */}
        <Card className="mb-6">
          <CardContent className="pt-4 pb-4">
            <div className="flex flex-wrap items-center gap-3">
              <Select value={territory} onValueChange={setTerritory}>
                <SelectTrigger className="w-44">
                  <SelectValue placeholder="Territory" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Territories</SelectItem>
                  <SelectItem value="North">North India</SelectItem>
                  <SelectItem value="South">South India</SelectItem>
                  <SelectItem value="East">East India</SelectItem>
                  <SelectItem value="West">West India</SelectItem>
                </SelectContent>
              </Select>
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">Last 7 days</SelectItem>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={fetchInsights} disabled={loading} className="gap-2">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                Generate Insights
              </Button>
            </div>
          </CardContent>
        </Card>

        {!insights && !loading && (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center mb-4">
              <Lightbulb className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Generate AI Insights</h3>
            <p className="text-sm text-center max-w-md">
              Select your territory and time period, then click "Generate Insights" to get AI-powered analysis of your HCP engagement, opportunities, and risks.
            </p>
          </div>
        )}

        {loading && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
            </div>
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
            </div>
          </div>
        )}

        {insights && !loading && (
          <>
            {/* Summary Cards */}
            {Object.keys(summary).length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                {summary.total_interactions !== undefined && (
                  <Card>
                    <CardContent className="pt-5">
                      <p className="text-xs text-muted-foreground">Total Interactions</p>
                      <p className="text-2xl font-bold text-blue-600 mt-1">{summary.total_interactions}</p>
                    </CardContent>
                  </Card>
                )}
                {summary.hcps_engaged !== undefined && (
                  <Card>
                    <CardContent className="pt-5">
                      <p className="text-xs text-muted-foreground">HCPs Engaged</p>
                      <p className="text-2xl font-bold text-green-600 mt-1">{summary.hcps_engaged}</p>
                    </CardContent>
                  </Card>
                )}
                {summary.avg_sentiment !== undefined && (
                  <Card>
                    <CardContent className="pt-5">
                      <p className="text-xs text-muted-foreground">Avg Sentiment</p>
                      <p className="text-2xl font-bold text-purple-600 mt-1">{summary.avg_sentiment?.toFixed(1)}/10</p>
                    </CardContent>
                  </Card>
                )}
                {summary.high_opportunity_count !== undefined && (
                  <Card>
                    <CardContent className="pt-5">
                      <p className="text-xs text-muted-foreground">High Opportunity</p>
                      <p className="text-2xl font-bold text-orange-500 mt-1">{summary.high_opportunity_count}</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}

            {/* Insight Cards */}
            {insightsList.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No specific insights generated for this period.</p>
            ) : (
              <div className="space-y-3">
                {insightsList.map((insight: InsightCard, i: number) => (
                  <Card key={i} className={`border-l-4 ${priorityColors[insight.priority] || "border-l-gray-300"}`}>
                    <CardContent className="pt-4 pb-4">
                      <div className="flex items-start gap-3">
                        <div className="shrink-0 mt-0.5">
                          {insight.type === "opportunity" ? (
                            <Target className="w-5 h-5 text-green-600" />
                          ) : insight.type === "risk" ? (
                            <AlertCircle className="w-5 h-5 text-red-600" />
                          ) : (
                            <TrendingUp className="w-5 h-5 text-blue-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-sm">{insight.title}</h3>
                            <Badge variant={priorityBadge[insight.priority]} className="text-xs capitalize">
                              {insight.priority} priority
                            </Badge>
                            <Badge variant="outline" className="text-xs capitalize">{insight.type}</Badge>
                          </div>
                          <p className="text-sm text-gray-600">{insight.description}</p>
                          {insight.action && (
                            <p className="text-xs text-blue-700 mt-2 font-medium">→ {insight.action}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* AI Analysis */}
            {insights.analysis && (
              <Card className="mt-6 border-purple-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2 text-purple-700">
                    <Lightbulb className="w-4 h-4" /> AI Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{insights.analysis}</p>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </AppLayout>
  );
}
