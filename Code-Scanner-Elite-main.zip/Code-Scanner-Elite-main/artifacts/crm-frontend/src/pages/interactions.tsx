import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useListInteractions } from "@workspace/api-client-react";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { History, Search, MessageSquarePlus, Calendar, Clock, ChevronRight, Stethoscope } from "lucide-react";
import { cn } from "@/lib/utils";

const interestColors: Record<string, string> = {
  Hot: "bg-red-100 text-red-700",
  High: "bg-green-100 text-green-700",
  Medium: "bg-yellow-100 text-yellow-700",
  Low: "bg-gray-100 text-gray-600",
};

export default function InteractionsPage() {
  const { token } = useSelector((state: RootState) => state.auth);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("");

  const { data, isLoading } = useListInteractions(
    { search: search || undefined, interaction_type: typeFilter || undefined, page, limit: 15 },
    { request: { headers: { Authorization: `Bearer ${token}` } } }
  );

  const interactions = (data as any)?.data || [];
  const total = (data as any)?.total || 0;
  const totalPages = Math.ceil(total / 15);

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <History className="w-6 h-6 text-blue-600" /> Interaction History
            </h1>
            <p className="text-sm text-muted-foreground mt-1">{total} total interactions logged</p>
          </div>
          <Link href="/log-interaction">
            <Button size="sm" className="gap-2">
              <MessageSquarePlus className="w-4 h-4" /> Log New
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Search by HCP name or notes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={typeFilter || "all"} onValueChange={(v) => setTypeFilter(v === "all" ? "" : v)}>
            <SelectTrigger className="w-44">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Visit">Visit</SelectItem>
              <SelectItem value="Call">Call</SelectItem>
              <SelectItem value="Lunch Meet">Lunch Meet</SelectItem>
              <SelectItem value="Webinar">Webinar</SelectItem>
              <SelectItem value="Email">Email</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* List */}
        {isLoading ? (
          <div className="space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}</div>
        ) : interactions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <History className="w-12 h-12 mb-3 opacity-30" />
            <p className="text-lg font-medium">No interactions found</p>
            <p className="text-sm">Try adjusting your search filters</p>
          </div>
        ) : (
          <div className="space-y-3">
            {interactions.map((interaction: any) => (
              <Card key={interaction.id} className="hover:shadow-md transition-shadow">
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                      <Stethoscope className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="font-semibold text-sm">{interaction.hcp_name || "HCP"}</span>
                        <Badge variant="outline" className="text-xs">{interaction.interaction_type}</Badge>
                        {interaction.interest_level && (
                          <span className={cn("text-xs px-2 py-0.5 rounded-full font-medium", interestColors[interaction.interest_level] || "bg-gray-100 text-gray-600")}>
                            {interaction.interest_level}
                          </span>
                        )}
                        {interaction.sentiment_score && (
                          <span className="text-xs text-muted-foreground">
                            Score: {interaction.sentiment_score}/10
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground mb-2">
                        <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{interaction.date}</span>
                        {interaction.duration_minutes && (
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{interaction.duration_minutes} min</span>
                        )}
                        {interaction.location && <span>📍 {interaction.location}</span>}
                      </div>
                      {interaction.ai_summary && (
                        <p className="text-xs text-gray-600 line-clamp-2">{interaction.ai_summary}</p>
                      )}
                      {interaction.products_discussed?.length > 0 && (
                        <div className="flex gap-1 mt-2 flex-wrap">
                          {interaction.products_discussed.map((p: string) => (
                            <Badge key={p} variant="secondary" className="text-xs px-1.5 py-0">{p}</Badge>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      {interaction.followup_needed && (
                        <Badge variant="outline" className="text-xs text-orange-600 border-orange-200 bg-orange-50">
                          Follow-up: {interaction.followup_date}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-6">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
            <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
