import { AppLayout } from "@/components/layout/AppLayout";
import { useGetHcp } from "@workspace/api-client-react";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link, useParams } from "wouter";
import { ArrowLeft, Phone, Mail, MapPin, Building2, Star, MessageSquarePlus, Calendar, TrendingUp } from "lucide-react";

const tierColors: Record<string, string> = {
  A: "bg-red-100 text-red-700 border-red-200",
  B: "bg-orange-100 text-orange-700 border-orange-200",
  C: "bg-blue-100 text-blue-700 border-blue-200",
};

export default function HcpDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { token } = useSelector((state: RootState) => state.auth);

  const { data: hcpDetail, isLoading } = useGetHcp(Number(id), {
    request: { headers: { Authorization: `Bearer ${token}` } }
  });

  const hcp = hcpDetail?.hcp;
  const recentInteractions = hcpDetail?.recent_interactions || [];
  const sentimentScore = (hcpDetail as any)?.average_sentiment || null;

  if (isLoading) {
    return (
      <AppLayout>
        <div className="p-6 max-w-5xl mx-auto space-y-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-48 rounded-xl" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Skeleton className="h-40 rounded-xl" />
            <Skeleton className="h-40 rounded-xl" />
          </div>
        </div>
      </AppLayout>
    );
  }

  if (!hcp) {
    return (
      <AppLayout>
        <div className="p-6 text-center">
          <p className="text-muted-foreground">HCP not found.</p>
          <Link href="/hcps"><Button variant="link">Back to directory</Button></Link>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Link href="/hcps">
            <Button variant="ghost" size="sm" className="gap-1">
              <ArrowLeft className="w-4 h-4" /> Back
            </Button>
          </Link>
        </div>

        {/* HCP Profile Card */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-6">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-400 to-indigo-600 flex items-center justify-center text-white font-bold text-3xl shrink-0">
                {hcp.name?.charAt(0)}
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap items-start gap-3 mb-3">
                  <h1 className="text-2xl font-bold text-gray-900">{hcp.name}</h1>
                  <span className={`text-sm font-semibold px-3 py-1 rounded-full border ${tierColors[hcp.tier] || "bg-gray-100 text-gray-700"}`}>
                    Tier {hcp.tier}
                  </span>
                </div>
                <p className="text-base text-muted-foreground mb-3">{hcp.specialty}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {(hcp as any).organization && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Building2 className="w-4 h-4 text-blue-500 shrink-0" />
                      {(hcp as any).organization}
                    </div>
                  )}
                  {hcp.city && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4 text-green-500 shrink-0" />
                      {hcp.city}{hcp.state ? `, ${hcp.state}` : ""}
                    </div>
                  )}
                  {hcp.phone && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4 text-orange-500 shrink-0" />
                      {hcp.phone}
                    </div>
                  )}
                  {hcp.email && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4 text-purple-500 shrink-0" />
                      {hcp.email}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col gap-2 sm:items-end">
                <Link href={`/log-interaction?hcp_id=${hcp.id}`}>
                  <Button className="gap-2 w-full sm:w-auto">
                    <MessageSquarePlus className="w-4 h-4" /> Log Visit
                  </Button>
                </Link>
                {sentimentScore !== null && (
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${sentimentScore >= 8 ? "text-green-600" : sentimentScore >= 6 ? "text-yellow-500" : "text-red-500"}`}>
                      {sentimentScore?.toFixed(1)}/10
                    </div>
                    <p className="text-xs text-muted-foreground">Sentiment Score</p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left: Details */}
          <div className="space-y-4">
            {/* Products Discussed */}
            {hcpDetail?.products_discussed && hcpDetail.products_discussed.length > 0 && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-500" /> Products Discussed
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {hcpDetail.products_discussed.map((p: string) => (
                      <Badge key={p} variant="secondary">{p}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* KPI Stats */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-purple-500" /> Engagement Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total Interactions</span>
                  <span className="font-semibold">{(hcp as any).total_interactions ?? 0}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Avg Sentiment</span>
                  <span className="font-semibold">{sentimentScore ? `${sentimentScore.toFixed(1)}/10` : "—"}</span>
                </div>
                {(hcp as any).opportunity_score && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Opportunity Score</span>
                    <span className="font-semibold">{(hcp as any).opportunity_score}/100</span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* AI Summary */}
            {hcpDetail?.ai_summary && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">AI Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 leading-relaxed">{hcpDetail.ai_summary}</p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right: Interaction History */}
          <div className="md:col-span-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-blue-500" /> Interaction History
                </CardTitle>
                <Badge variant="outline">{recentInteractions.length} visits</Badge>
              </CardHeader>
              <CardContent>
                {recentInteractions.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground text-sm">No interactions yet</p>
                    <Link href={`/log-interaction?hcp_id=${hcp.id}`}>
                      <Button variant="link" size="sm">Log first visit</Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentInteractions.map((interaction: any) => (
                      <div key={interaction.id} className="border-l-2 border-blue-200 pl-4 py-1">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-blue-700">{interaction.interaction_type}</span>
                            <span className="text-xs text-muted-foreground">{interaction.date}</span>
                          </div>
                          {interaction.interest_level && (
                            <Badge variant="outline" className="text-xs">{interaction.interest_level}</Badge>
                          )}
                        </div>
                        {interaction.ai_summary && (
                          <p className="text-xs text-gray-600 leading-relaxed">{interaction.ai_summary}</p>
                        )}
                        {interaction.products_discussed?.length > 0 && (
                          <div className="flex gap-1 mt-1.5 flex-wrap">
                            {interaction.products_discussed.map((p: string) => (
                              <Badge key={p} variant="secondary" className="text-xs px-1.5 py-0">{p}</Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
