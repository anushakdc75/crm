import { AppLayout } from "@/components/layout/AppLayout";
import { useGetDashboard } from "@workspace/api-client-react";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Users, ActivitySquare, Bell, TrendingUp, AlertCircle,
  Phone, Calendar, ChevronRight, Stethoscope, Bot
} from "lucide-react";

function KpiCard({ title, value, subtitle, icon: Icon, color }: {
  title: string; value: string | number; subtitle?: string;
  icon: React.ElementType; color: string;
}) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className={`text-3xl font-bold mt-1 ${color}`}>{value}</p>
            {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
          </div>
          <div className={`p-3 rounded-full bg-opacity-10 ${color.replace('text-', 'bg-')}/10`}>
            <Icon className={`w-6 h-6 ${color}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function interestBadge(level: string) {
  const map: Record<string, string> = {
    Hot: "destructive", High: "default", Medium: "secondary", Low: "outline"
  };
  return <Badge variant={(map[level] || "outline") as any}>{level}</Badge>;
}

export default function DashboardPage() {
  const { token } = useSelector((state: RootState) => state.auth);
  const { data, isLoading } = useGetDashboard({
    request: { headers: { Authorization: `Bearer ${token}` } }
  });

  const kpis = data?.kpis;
  const recentInteractions = data?.recent_interactions || [];
  const pendingFollowups = data?.pending_followups || [];
  const topHcps = data?.top_hcps || [];

  return (
    <AppLayout>
      <div className="p-6 max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">Your pharma CRM overview</p>
        </div>

        {/* KPI Row */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          {isLoading ? [...Array(6)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />) : (
            <>
              <KpiCard title="Total HCPs" value={kpis?.total_hcps ?? 0} icon={Users} color="text-blue-600" />
              <KpiCard title="Week's Interactions" value={kpis?.week_interactions ?? 0} subtitle="This week" icon={ActivitySquare} color="text-green-600" />
              <KpiCard title="Pending Follow-ups" value={kpis?.pending_followups ?? 0} icon={Bell} color="text-orange-500" />
              <KpiCard title="High Opportunity" value={kpis?.high_opportunity_hcps ?? 0} subtitle="HCPs" icon={TrendingUp} color="text-purple-600" />
              <KpiCard title="At-Risk Accounts" value={kpis?.at_risk_accounts ?? 0} icon={AlertCircle} color="text-red-500" />
              <KpiCard title="Monthly Calls" value={kpis?.monthly_calls ?? 0} icon={Phone} color="text-cyan-600" />
            </>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Interactions */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base">Recent Interactions</CardTitle>
                <Link href="/interactions">
                  <Button variant="ghost" size="sm" className="text-xs">
                    View all <ChevronRight className="w-3 h-3 ml-1" />
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-3">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
                ) : recentInteractions.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">No recent interactions</p>
                ) : (
                  <div className="space-y-3">
                    {recentInteractions.slice(0, 5).map((interaction: any) => (
                      <div key={interaction.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                        <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                          <Stethoscope className="w-4 h-4 text-blue-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium truncate">{interaction.hcp_name || "Dr."}</p>
                            {interaction.interest_level && interestBadge(interaction.interest_level)}
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{interaction.interaction_type} • {interaction.date}</p>
                          {interaction.ai_summary && (
                            <p className="text-xs text-gray-600 mt-1 line-clamp-1">{interaction.ai_summary}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-4">
            {/* Pending Follow-ups */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Bell className="w-4 h-4 text-orange-500" /> Pending Follow-ups
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
                ) : pendingFollowups.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">No pending follow-ups</p>
                ) : (
                  <div className="space-y-2">
                    {pendingFollowups.slice(0, 4).map((f: any) => (
                      <div key={f.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-gray-50">
                        <Calendar className="w-4 h-4 text-orange-400 shrink-0" />
                        <div className="min-w-0">
                          <p className="text-xs font-medium truncate">{f.hcp_name}</p>
                          <p className="text-xs text-muted-foreground">{f.followup_date} • {f.followup_mode}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Top HCPs */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-purple-600" /> Top HCPs
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
                ) : topHcps.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">No data</p>
                ) : (
                  <div className="space-y-2">
                    {topHcps.slice(0, 5).map((h: any) => (
                      <Link key={h.id} href={`/hcps/${h.id}`}>
                        <div className="flex items-center justify-between p-2 rounded-md hover:bg-gray-50 cursor-pointer">
                          <div>
                            <p className="text-xs font-medium">{h.name}</p>
                            <p className="text-xs text-muted-foreground">{h.specialty}</p>
                          </div>
                          <Badge variant="outline" className="text-xs">{h.tier}</Badge>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* AI Assistant CTA */}
            <Card className="bg-gradient-to-br from-purple-600 to-indigo-700 text-white border-0">
              <CardContent className="pt-6">
                <Bot className="w-8 h-8 mb-2 opacity-90" />
                <h3 className="font-semibold mb-1">AI Assistant</h3>
                <p className="text-xs opacity-80 mb-3">Log interactions using natural language. Just describe your visit!</p>
                <Link href="/log-interaction">
                  <Button size="sm" variant="secondary" className="w-full text-purple-700">
                    Open AI Assistant
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
