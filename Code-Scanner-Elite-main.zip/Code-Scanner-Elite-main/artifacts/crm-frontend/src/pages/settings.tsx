import { AppLayout } from "@/components/layout/AppLayout";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Settings, User, Shield, Bell, Database, Bot } from "lucide-react";

export default function SettingsPage() {
  const { user } = useSelector((state: RootState) => state.auth);

  return (
    <AppLayout>
      <div className="p-6 max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Settings className="w-6 h-6 text-gray-600" /> Settings
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your account and application preferences</p>
        </div>

        <div className="space-y-4">
          {/* Profile */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <User className="w-4 h-4 text-blue-500" /> Profile
              </CardTitle>
              <CardDescription>Your account information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-400 to-indigo-600 flex items-center justify-center text-white text-xl font-bold">
                  {user?.full_name?.charAt(0) || "U"}
                </div>
                <div>
                  <h3 className="font-semibold">{user?.full_name || "User"}</h3>
                  <p className="text-sm text-muted-foreground">{user?.username}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="secondary" className="capitalize">{user?.role || "rep"}</Badge>
                    {user?.territory && <Badge variant="outline">{user.territory}</Badge>}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Configuration */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Bot className="w-4 h-4 text-purple-500" /> AI Configuration
              </CardTitle>
              <CardDescription>LangGraph AI workflow settings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b">
                  <div>
                    <p className="text-sm font-medium">Primary Model</p>
                    <p className="text-xs text-muted-foreground">Used for interaction analysis</p>
                  </div>
                  <Badge className="bg-green-100 text-green-700 border-green-200">OpenAI GPT-4o</Badge>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <div>
                    <p className="text-sm font-medium">Fallback Model</p>
                    <p className="text-xs text-muted-foreground">Groq LLaMA-3.1 backup</p>
                  </div>
                  <Badge variant="outline">Groq LLaMA-3.1-70B</Badge>
                </div>
                <div className="flex justify-between items-center py-2">
                  <div>
                    <p className="text-sm font-medium">AI Workflow</p>
                    <p className="text-xs text-muted-foreground">8-node LangGraph pipeline</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-700 border-blue-200">Active</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Security */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="w-4 h-4 text-green-500" /> Security
              </CardTitle>
              <CardDescription>Authentication and access control</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b">
                  <div>
                    <p className="text-sm font-medium">Authentication</p>
                    <p className="text-xs text-muted-foreground">JWT Bearer tokens</p>
                  </div>
                  <Badge className="bg-green-100 text-green-700">Active</Badge>
                </div>
                <div className="flex justify-between items-center py-2">
                  <div>
                    <p className="text-sm font-medium">Session</p>
                    <p className="text-xs text-muted-foreground">Token expires in 24 hours</p>
                  </div>
                  <Badge variant="outline">JWT</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Bell className="w-4 h-4 text-orange-500" /> Notifications
              </CardTitle>
              <CardDescription>Follow-up reminders and alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between py-2">
                <p className="text-sm text-muted-foreground">Follow-up reminders, AI alerts, and territory updates appear on the Dashboard.</p>
              </div>
            </CardContent>
          </Card>

          {/* Database */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Database className="w-4 h-4 text-gray-500" /> Database
              </CardTitle>
              <CardDescription>PostgreSQL connection status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600">PostgreSQL (Replit managed)</p>
                <Badge className="bg-green-100 text-green-700">Connected</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
