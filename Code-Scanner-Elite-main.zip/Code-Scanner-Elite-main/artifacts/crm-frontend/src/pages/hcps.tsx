import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useListHcps } from "@workspace/api-client-react";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "@/store";
import { setFilters } from "@/features/hcpSlice";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { Search, Users, MapPin, Star, ChevronRight, Phone, UserPlus } from "lucide-react";

const tierColors: Record<string, string> = {
  A: "bg-red-100 text-red-700",
  B: "bg-orange-100 text-orange-700",
  C: "bg-blue-100 text-blue-700",
};

export default function HcpListPage() {
  const { token } = useSelector((state: RootState) => state.auth);
  const { filters } = useSelector((state: RootState) => state.hcp);
  const dispatch = useDispatch();
  const [page, setPage] = useState(1);

  const { data, isLoading } = useListHcps(
    { search: filters.search || undefined, specialty: filters.specialty || undefined, city: filters.city || undefined, tier: filters.tier || undefined, page, limit: 12 },
    { request: { headers: { Authorization: `Bearer ${token}` } } }
  );

  const hcps = (data as any)?.data || [];
  const total = data?.total || 0;
  const totalPages = Math.ceil(total / 12);

  return (
    <AppLayout>
      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Users className="w-6 h-6 text-blue-600" /> HCP Directory
            </h1>
            <p className="text-sm text-muted-foreground mt-1">{total} healthcare professionals</p>
          </div>
          <Link href="/hcps/new">
            <Button size="sm" className="gap-2">
              <UserPlus className="w-4 h-4" /> Add HCP
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Search by name, hospital, city..."
              value={filters.search}
              onChange={(e) => dispatch(setFilters({ search: e.target.value }))}
            />
          </div>
          <Select value={filters.specialty || "all"} onValueChange={(v) => dispatch(setFilters({ specialty: v === "all" ? "" : v }))}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Specialty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Specialties</SelectItem>
              <SelectItem value="Diabetologist">Diabetologist</SelectItem>
              <SelectItem value="Cardiologist">Cardiologist</SelectItem>
              <SelectItem value="Neurologist">Neurologist</SelectItem>
              <SelectItem value="General Physician">General Physician</SelectItem>
              <SelectItem value="Orthopedic Surgeon">Orthopedic Surgeon</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.tier || "all"} onValueChange={(v) => dispatch(setFilters({ tier: v === "all" ? "" : v }))}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Tier" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tiers</SelectItem>
              <SelectItem value="A">Tier A</SelectItem>
              <SelectItem value="B">Tier B</SelectItem>
              <SelectItem value="C">Tier C</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-48 rounded-xl" />)}
          </div>
        ) : hcps.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Users className="w-12 h-12 mb-3 opacity-30" />
            <p className="text-lg font-medium">No HCPs found</p>
            <p className="text-sm">Try adjusting your search filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {hcps.map((hcp: any) => (
              <Link key={hcp.id} href={`/hcps/${hcp.id}`}>
                <Card className="hover:shadow-md transition-all cursor-pointer group border hover:border-blue-200">
                  <CardContent className="pt-5 pb-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-full bg-gradient-to-br from-blue-400 to-indigo-600 flex items-center justify-center text-white font-bold text-lg shrink-0">
                          {hcp.name?.charAt(0)}
                        </div>
                        <div>
                          <p className="font-semibold text-sm leading-tight">{hcp.name}</p>
                          <p className="text-xs text-muted-foreground">{hcp.specialty}</p>
                        </div>
                      </div>
                      <span className={`text-xs font-bold px-2 py-1 rounded-full ${tierColors[hcp.tier] || "bg-gray-100 text-gray-700"}`}>
                        Tier {hcp.tier}
                      </span>
                    </div>

                    <div className="space-y-1.5">
                      {((hcp as any).organization || (hcp as any).hospital) && (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Star className="w-3 h-3 shrink-0" />
                          <span className="truncate">{(hcp as any).organization || (hcp as any).hospital}</span>
                        </div>
                      )}
                      {hcp.city && (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <MapPin className="w-3 h-3 shrink-0" />
                          <span>{hcp.city}</span>
                        </div>
                      )}
                      {hcp.phone && (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Phone className="w-3 h-3 shrink-0" />
                          <span>{hcp.phone}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between mt-3 pt-3 border-t">
                      <div className="flex gap-1 flex-wrap">
                        {(hcp as any).priority && (
                          <Badge variant="outline" className="text-xs">
                            {(hcp as any).priority}
                          </Badge>
                        )}
                        {(hcp as any).total_interactions !== undefined && (
                          <span className="text-xs text-muted-foreground">{(hcp as any).total_interactions} visits</span>
                        )}
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-blue-600 transition-colors" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-6">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
            <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
