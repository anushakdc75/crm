import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useCreateHcp } from "@workspace/api-client-react";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Loader2, UserPlus } from "lucide-react";
import { Link } from "wouter";

export default function HcpNewPage() {
  const { token } = useSelector((state: RootState) => state.auth);
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({
    name: "", specialty: "", organization: "", city: "", state: "",
    phone: "", email: "", tier: "B", notes: "", products_focus: "",
  });

  const { mutate: createHcp, isPending } = useCreateHcp({
    mutation: {
      onSuccess: (data: any) => setLocation(`/hcps/${data.id}`),
    },
    request: { headers: { Authorization: `Bearer ${token}` } },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createHcp({
      data: {
        ...form,
        products_focus: form.products_focus ? form.products_focus.split(",").map(s => s.trim()) : [],
      }
    });
  };

  const set = (field: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [field]: e.target.value }));

  return (
    <AppLayout>
      <div className="p-6 max-w-2xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Link href="/hcps">
            <Button variant="ghost" size="sm" className="gap-1"><ArrowLeft className="w-4 h-4" /> Back</Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-blue-600" /> Add New HCP
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Full Name *</Label>
                  <Input value={form.name} onChange={set("name")} placeholder="Dr. Priya Sharma" required />
                </div>
                <div className="space-y-1.5">
                  <Label>Prescribing Volume</Label>
                  <Select value={(form as any).prescribing_volume || "medium"} onValueChange={(v) => setForm(f => ({ ...f, prescribing_volume: v }))}>
                    <SelectTrigger><SelectValue placeholder="Prescribing volume" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Specialty *</Label>
                  <Select value={form.specialty} onValueChange={(v) => setForm(f => ({ ...f, specialty: v }))}>
                    <SelectTrigger><SelectValue placeholder="Select specialty" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Diabetologist">Diabetologist</SelectItem>
                      <SelectItem value="Cardiologist">Cardiologist</SelectItem>
                      <SelectItem value="Neurologist">Neurologist</SelectItem>
                      <SelectItem value="General Physician">General Physician</SelectItem>
                      <SelectItem value="Orthopedic Surgeon">Orthopedic Surgeon</SelectItem>
                      <SelectItem value="Immunologist">Immunologist</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Tier</Label>
                  <Select value={form.tier} onValueChange={(v) => setForm(f => ({ ...f, tier: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A">Tier A (High Value)</SelectItem>
                      <SelectItem value="B">Tier B (Medium)</SelectItem>
                      <SelectItem value="C">Tier C (Developing)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Hospital / Clinic</Label>
                  <Input value={form.organization} onChange={set("organization")} placeholder="Apollo Hospital" />
                </div>
                <div className="space-y-1.5">
                  <Label>City</Label>
                  <Input value={form.city} onChange={set("city")} placeholder="Mumbai" />
                </div>
                <div className="space-y-1.5">
                  <Label>State</Label>
                  <Input value={form.state} onChange={set("state")} placeholder="Maharashtra" />
                </div>
                <div className="space-y-1.5">
                  <Label>Phone</Label>
                  <Input value={form.phone} onChange={set("phone")} placeholder="+91 98765 43210" />
                </div>
                <div className="sm:col-span-2 space-y-1.5">
                  <Label>Email</Label>
                  <Input type="email" value={form.email} onChange={set("email")} placeholder="dr.sharma@hospital.com" />
                </div>
                <div className="sm:col-span-2 space-y-1.5">
                  <Label>Products Focus (comma-separated)</Label>
                  <Input value={form.products_focus} onChange={set("products_focus")} placeholder="GlucoCare, CardioMax" />
                </div>
                <div className="sm:col-span-2 space-y-1.5">
                  <Label>Notes</Label>
                  <Textarea value={form.notes} onChange={set("notes")} placeholder="Key details about this HCP..." rows={3} />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <Button type="submit" disabled={isPending || !form.name || !form.specialty} className="gap-2">
                  {isPending && <Loader2 className="w-4 h-4 animate-spin" />}
                  Add HCP
                </Button>
                <Link href="/hcps">
                  <Button type="button" variant="outline">Cancel</Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
