import { useState, useRef, useEffect } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "@/store";
import { addMessage, setIsLoading, clearChat, setConversationId, setExtractedData, ChatMessage } from "@/features/chatSlice";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Bot, User, Send, RotateCcw, CheckCircle, AlertCircle, Sparkles, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function LogInteractionPage() {
  const dispatch = useDispatch();
  const { token } = useSelector((state: RootState) => state.auth);
  const { messages, conversation_id, extracted_data, is_loading } = useSelector((state: RootState) => state.chat);
  const [input, setInput] = useState("");
  const [saved, setSaved] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, is_loading]);

  const sendMessage = async () => {
    if (!input.trim() || is_loading) return;
    const userMsg: ChatMessage = { role: "user", content: input };
    dispatch(addMessage(userMsg));
    const currentInput = input;
    setInput("");
    dispatch(setIsLoading(true));

    try {
      const res = await fetch(`${API_BASE}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ message: currentInput, conversation_id }),
      });
      const data = await res.json();
      if (data.conversation_id) dispatch(setConversationId(data.conversation_id));
      if (data.extracted_data) dispatch(setExtractedData(data.extracted_data));

      const assistantMsg: ChatMessage = {
        role: "assistant",
        content: data.reply,
        extracted_data: data.extracted_data,
        follow_up_questions: data.follow_up_questions,
        confidence_score: data.confidence_score,
      };
      dispatch(addMessage(assistantMsg));
    } catch {
      dispatch(addMessage({
        role: "assistant",
        content: "Sorry, I encountered an error. Please try again.",
      }));
    } finally {
      dispatch(setIsLoading(false));
    }
  };

  const saveInteraction = async () => {
    if (!conversation_id) return;
    try {
      const res = await fetch(`${API_BASE}/api/chat/save/${conversation_id}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setSaved(true);
        setTimeout(() => {
          dispatch(clearChat());
          setSaved(false);
        }, 2000);
      }
    } catch {}
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const suggestedPrompts = [
    "Met Dr. Sharma at AIIMS today for 45 mins. Discussed GlucoCare for his diabetic patients. Very interested, wants clinical data. Will follow up next week.",
    "Called Dr. Mehta about CardioMax. She raised pricing concerns compared to Novartis. Sentiment medium. Need to schedule a visit.",
    "Attended webinar with Dr. Khan on NeuroPlus. He was very engaged, hot prospect. Setting up a demo visit next Tuesday.",
  ];

  return (
    <AppLayout>
      <div className="p-6 max-w-6xl mx-auto h-full flex flex-col">
        <div className="mb-4">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Bot className="w-6 h-6 text-purple-600" /> AI Interaction Logger
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Describe your HCP visit in natural language — the AI will extract and log all the details</p>
        </div>

        <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 min-h-0">
          {/* Chat Area */}
          <div className="lg:col-span-2 flex flex-col">
            <Card className="flex-1 flex flex-col min-h-0">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-500" /> Conversation
                </CardTitle>
                {messages.length > 0 && (
                  <Button variant="ghost" size="sm" onClick={() => dispatch(clearChat())} className="text-xs h-7">
                    <RotateCcw className="w-3 h-3 mr-1" /> New
                  </Button>
                )}
              </CardHeader>
              <CardContent className="flex-1 flex flex-col min-h-0 pb-4">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1">
                  {messages.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full gap-4 py-8">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
                        <Bot className="w-9 h-9 text-white" />
                      </div>
                      <div className="text-center">
                        <h3 className="font-semibold text-gray-800">Hi! I'm your AI CRM assistant</h3>
                        <p className="text-sm text-muted-foreground mt-1 max-w-sm">Tell me about your HCP visit and I'll extract all the key details automatically</p>
                      </div>
                      <div className="space-y-2 w-full max-w-md">
                        <p className="text-xs font-medium text-muted-foreground text-center">Try an example:</p>
                        {suggestedPrompts.map((p, i) => (
                          <button
                            key={i}
                            className="w-full text-left text-xs p-3 rounded-lg border hover:bg-purple-50 hover:border-purple-200 transition-colors"
                            onClick={() => setInput(p)}
                          >
                            "{p.slice(0, 80)}..."
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {messages.map((msg, i) => (
                    <div key={i} className={cn("flex gap-3", msg.role === "user" ? "justify-end" : "justify-start")}>
                      {msg.role === "assistant" && (
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shrink-0 mt-1">
                          <Bot className="w-4 h-4 text-white" />
                        </div>
                      )}
                      <div className={cn("max-w-[85%] rounded-2xl px-4 py-3", msg.role === "user"
                        ? "bg-blue-600 text-white rounded-tr-sm"
                        : "bg-gray-100 text-gray-800 rounded-tl-sm"
                      )}>
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                        {msg.confidence_score && (
                          <div className="mt-2 flex items-center gap-1">
                            <div className={cn("w-2 h-2 rounded-full", msg.confidence_score >= 0.8 ? "bg-green-500" : msg.confidence_score >= 0.6 ? "bg-yellow-500" : "bg-red-500")} />
                            <span className="text-xs opacity-70">Confidence: {(msg.confidence_score * 100).toFixed(0)}%</span>
                          </div>
                        )}
                        {msg.follow_up_questions && msg.follow_up_questions.length > 0 && (
                          <div className="mt-2 space-y-1">
                            {msg.follow_up_questions.map((q: string, j: number) => (
                              <button key={j} onClick={() => setInput(q)}
                                className="block w-full text-left text-xs underline underline-offset-2 opacity-70 hover:opacity-100">
                                → {q}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      {msg.role === "user" && (
                        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center shrink-0 mt-1">
                          <User className="w-4 h-4 text-blue-600" />
                        </div>
                      )}
                    </div>
                  ))}

                  {is_loading && (
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                      <div className="bg-gray-100 rounded-2xl rounded-tl-sm px-4 py-3">
                        <div className="flex gap-1 items-center">
                          <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                          <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                          <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "300ms" }} />
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="flex gap-2">
                  <Textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Describe your HCP visit... (Shift+Enter for new line)"
                    className="resize-none min-h-[80px] text-sm"
                    disabled={is_loading}
                  />
                  <Button onClick={sendMessage} disabled={is_loading || !input.trim()} size="icon" className="h-auto w-12 shrink-0">
                    {is_loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Extracted Data Panel */}
          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" /> Extracted Data
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!extracted_data || Object.keys(extracted_data).length === 0 ? (
                  <div className="text-center py-6">
                    <AlertCircle className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                    <p className="text-xs text-muted-foreground">Start chatting and I'll extract the interaction details here</p>
                  </div>
                ) : (
                  <div className="space-y-2 text-sm">
                    {Object.entries(extracted_data).filter(([, v]) => v !== null && v !== undefined && v !== "").map(([key, value]) => (
                      <div key={key} className="flex flex-col gap-0.5">
                        <span className="text-xs font-medium text-muted-foreground capitalize">{key.replace(/_/g, " ")}</span>
                        <span className="text-xs text-gray-800 font-medium">
                          {Array.isArray(value) ? value.join(", ") : String(value)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {extracted_data && Object.keys(extracted_data).length > 0 && (
              <Button
                className="w-full gap-2"
                onClick={saveInteraction}
                disabled={saved}
              >
                {saved ? (
                  <><CheckCircle className="w-4 h-4" /> Saved!</>
                ) : (
                  <><CheckCircle className="w-4 h-4" /> Save Interaction</>
                )}
              </Button>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
