import { configureStore } from '@reduxjs/toolkit';
import authReducer from './features/authSlice';
import hcpReducer from './features/hcpSlice';
import interactionReducer from './features/interactionSlice';
import chatReducer from './features/chatSlice';
import uiReducer from './features/uiSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    hcp: hcpReducer,
    interaction: interactionReducer,
    chat: chatReducer,
    ui: uiReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
