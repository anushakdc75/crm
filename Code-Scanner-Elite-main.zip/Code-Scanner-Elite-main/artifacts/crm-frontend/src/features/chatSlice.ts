import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { ExtractedInteractionData } from '@workspace/api-client-react';

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  extracted_data?: ExtractedInteractionData;
  follow_up_questions?: string[];
  confidence_score?: number;
}

interface ChatState {
  messages: ChatMessage[];
  conversation_id: string | null;
  extracted_data: ExtractedInteractionData | null;
  is_loading: boolean;
}

const initialState: ChatState = {
  messages: [],
  conversation_id: null,
  extracted_data: null,
  is_loading: false,
};

const chatSlice = createSlice({
  name: 'chat',
  initialState,
  reducers: {
    addMessage(state, action: PayloadAction<ChatMessage>) {
      state.messages.push(action.payload);
    },
    setConversationId(state, action: PayloadAction<string>) {
      state.conversation_id = action.payload;
    },
    setExtractedData(state, action: PayloadAction<ExtractedInteractionData>) {
      state.extracted_data = { ...state.extracted_data, ...action.payload };
    },
    setIsLoading(state, action: PayloadAction<boolean>) {
      state.is_loading = action.payload;
    },
    clearChat(state) {
      state.messages = [];
      state.conversation_id = null;
      state.extracted_data = null;
      state.is_loading = false;
    }
  },
});

export const { addMessage, setConversationId, setExtractedData, setIsLoading, clearChat } = chatSlice.actions;
export default chatSlice.reducer;