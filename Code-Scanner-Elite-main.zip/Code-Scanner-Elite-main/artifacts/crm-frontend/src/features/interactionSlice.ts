import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { CreateInteractionRequest } from '@workspace/api-client-react';

interface InteractionState {
  draft_form: Partial<CreateInteractionRequest>;
  current_mode: 'form' | 'chat';
}

const initialState: InteractionState = {
  draft_form: {
    date: new Date().toISOString().split('T')[0],
    interaction_type: 'Visit',
    products_discussed: [],
  },
  current_mode: 'form',
};

const interactionSlice = createSlice({
  name: 'interaction',
  initialState,
  reducers: {
    updateDraft(state, action: PayloadAction<Partial<CreateInteractionRequest>>) {
      state.draft_form = { ...state.draft_form, ...action.payload };
    },
    setMode(state, action: PayloadAction<'form' | 'chat'>) {
      state.current_mode = action.payload;
    },
    resetDraft(state) {
      state.draft_form = initialState.draft_form;
    }
  },
});

export const { updateDraft, setMode, resetDraft } = interactionSlice.actions;
export default interactionSlice.reducer;