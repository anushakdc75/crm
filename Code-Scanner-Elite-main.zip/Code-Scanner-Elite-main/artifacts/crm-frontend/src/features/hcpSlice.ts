import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface HcpState {
  selected_hcp: number | null;
  filters: {
    search: string;
    specialty: string;
    city: string;
    tier: string;
  };
}

const initialState: HcpState = {
  selected_hcp: null,
  filters: {
    search: '',
    specialty: '',
    city: '',
    tier: '',
  },
};

const hcpSlice = createSlice({
  name: 'hcp',
  initialState,
  reducers: {
    setSelectedHcp(state, action: PayloadAction<number | null>) {
      state.selected_hcp = action.payload;
    },
    setFilters(state, action: PayloadAction<Partial<HcpState['filters']>>) {
      state.filters = { ...state.filters, ...action.payload };
    },
  },
});

export const { setSelectedHcp, setFilters } = hcpSlice.actions;
export default hcpSlice.reducer;